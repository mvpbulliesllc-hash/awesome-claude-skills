# LOCKS.md — Keys & Secrets: Locked Rules

Non-negotiable handling rules for every credential this system touches.
**No secret values ever appear in this file, this repo, docs, code, commit
history, or chat/PR text.** This file is the inventory and the rules — the
values live only in runtime environments.

## Inventory (names, never values)

| Credential | Env var / location | Used by | Scope it should have |
|---|---|---|---|
| Google Maps Platform key | `GOOGLE_MAPS_API_KEY` (Cloud Run env / operator env) | roof-intel + route ordering | API-restricted (Solar, Geocoding, Address Validation, Routes, Street View) + referrer/IP restricted |
| Workspace service account | `GOOGLE_APPLICATION_CREDENTIALS` → JSON key file outside the repo | gws jobs on the Cloud Run runner | domain-wide delegation limited to the exact scopes in ARCHITECTURE.md §2 |
| Operator OAuth (interactive) | `gws auth login` local token cache | manual ops from operator machines | user-consent scopes only |
| Anthropic key | `ANTHROPIC_API_KEY` | vision damage pass (roof-scan-qualify Stage 3) | standard |
| NOAA SWDI / api.weather.gov | — (keyless) | storm engine | n/a |
| EagleView (later phase) | `EAGLEVIEW_API_KEY` (reserved name) | verified roof tier | not provisioned yet |

## Locked rules

1. **Env vars only.** Code and docs reference names, never values. No
   defaults, no fallbacks baked into scripts.
2. **Nothing in git.** `.gitignore` covers `.env`, `*.json` key files, token
   caches. `.env.example` carries names + empty values only.
3. **Never echoed.** Jobs must not print secrets to logs, Chat, Sheets, or
   email — including on error paths.
4. **Least scope.** Maps key API-restricted; service account gets only the
   scopes the component map requires; no owner/admin tokens in jobs.
5. **Rotation triggers.** Rotate immediately on: a key appearing in any
   shared artifact (doc, chat, screenshot, HTML sample), a person leaving,
   or a runner compromise. Rotation is a Config non-event — nothing else in
   the system changes.
6. **Known incident (standing action):** the Aerial View HTML sample that
   circulated with the mission brief contains a hardcoded `AIzaSy…` Maps key.
   Treat that key as exposed: rotate it in the `paragon-back-office` console
   and scrub the sample before it lands in any repo or shared drive. Done =
   old key returns 403 and the sample references `GOOGLE_MAPS_API_KEY`.
7. **Repo visibility is a secrets control.** This repo holds competitive
   strategy, territory logic, and outreach templates — it stays private.
   Review access is granted by adding a collaborator or pasting requested
   sections into the review channel, never by flipping the repo public.
