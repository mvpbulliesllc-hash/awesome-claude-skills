---
name: roof-scan-qualify
description: "Find, out of an entire area, the N roofs (default 100) with damage severe enough to justify a full roof-intel report + outreach. Funnel: enumerate → cold score → Solar geometry → vision damage pass → qualification bar."
---

# SKILL: roof-scan-qualify
Find, out of an entire area, the N roofs (default 100) with damage severe
enough to justify a full roof-intel report + outreach. This is a FUNNEL that
ranks and thresholds — not a report generator. Reports are produced only for
roofs that clear the bar.

## INPUT
Area (polygon, ZIP, or town) + optional storm-event overlay + target N.

## THE FUNNEL (cheap gates first — never run expensive analysis on roofs that fail early)

STAGE 0 — ENUMERATE (near-free)
- Get every rooftop/parcel in the area. Source: Google Open Buildings
  footprints (BigQuery public dataset) or the enriched address list if one
  exists for the area. Output: candidate list with lat/lng + footprint.

STAGE 1 — COLD SCORE (free, no imagery pulls): rank the whole candidate pool
on data you can get in bulk without spending per-roof:
- Storm exposure: NOAA SWDI hail intersect at each rooftop (keyless).
  Significant hail (>=1") in last 24mo = strong signal.
- Roof age proxy: permit history + assessor year-built (existing enrichment
  stack: Firecrawl/Brightdata/assessor). Older + no recent reroof permit =
  strong signal.
- Footprint size: bigger roof = bigger ticket (from Stage 0).
- Drop the bottom of the pool here. Only the top slice advances. This is the
  cost control — imagery/vision only touch survivors.

STAGE 2 — GEOMETRY (Solar API, per surviving roof): pull segments, pitch,
squares, imagery date/quality. Confirms it's a real pitched residential roof
worth analyzing, adds squares to the score. Solar's free tier covers this at
Paragon's volume.

STAGE 3 — VISION DAMAGE PASS (Claude, per survivor only): pull the ortho crop,
run the carrier-rubric prompt. Flags: tarp, missing/creased material,
staining, patching, ponding, exposed decking, each with confidence 0-1. This
is the accuracy edge RoofScope has no equivalent for and it runs on the
smallest set, so it stays cheap.

STAGE 4 — QUALIFY + RANK: composite = storm × age × squares × vision-severity.
Apply the QUALIFICATION BAR (below). Return the top N that CLEAR the bar. If
fewer than N clear, return what clears — never pad the list with roofs that
don't have real damage. A short honest list beats a padded one; reps burn
trust knocking on clean roofs.

## QUALIFICATION BAR (what "worth a report + outreach" means)
A roof qualifies only if BOTH:
- At least one vision damage flag at >=0.6 confidence, OR significant storm
  hit (>=1" hail) within the roof's exposure window, AND
- Roof age/condition consistent with a real replacement case (not a 2-year-old
  roof with a lucky camera angle).
Tune the threshold against ground truth as door-knock results come back. The
bar is a dial, not a constant.

## OUTPUT
Ranked qualified list written to the CRM (Sheet/DB): address, owner (from
enrichment), composite score, top flags w/ confidence, storm summary, est.
squares, report-slug. Daily run = the day's ~100-home strike queue, assigned
to field reps. Only qualified roofs get the full report page generated.

## GUARDRAILS
- Tiered cost is mandatory. Vision never runs on the full pool. If a run would
  vision-scan more than ~500 roofs, tighten Stage 1 first.
- Cache every API response permanently by address+imagery-date. Re-runs are free.
- Report projected spend before any full-area run. Run a 1-town pilot,
  extrapolate, then scale.
- Accuracy target: geometry within a few % of RoofScope ground truth
  (118 Porter Ave: 26.04 SQ, 9 planes) before this skill is trusted at scale.
- Outreach copy stays roof-condition + inspection only. No loan/insurance-
  outcome claims. (Standing licensing line.)
