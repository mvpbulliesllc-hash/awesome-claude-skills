# SYNC_MODEL — Keeping Field ↔ Ops ↔ Ownership Seamless

**Phase 0 design document.**

Three tiers, one source of truth (the master sheet), and a small set of jobs
that project sheet state out to the surfaces each tier actually looks at.
Nothing requires a rep to "check the system" — the system pushes to the app
they already have open.

---

## 1. What each tier sees and touches

| Tier | Reads | Writes | Surfaces |
|---|---|---|---|
| **Field reps** | Today's DailyQueue filter view; own Leads view; Tasks list; Calendar; report PDFs in Drive | Field Activity Form; whitelisted Lead columns; Task complete; Calendar RSVP | Sheets/Tasks/Calendar/Drive/Chat mobile apps |
| **Ops coordinators** | Whole master sheet; Gmail triage; Chat space | Everything; templated outreach sends; assignments overrides | Desktop Sheets + Gmail + Chat |
| **Ownership** | Dashboard tab; weekly digest Doc/email; Chat space (muted, mentions only) | Config (thresholds, territories, capacity) | Sheets Dashboard, Gmail, Docs |

## 2. Real-time vs. batched — the honest split

Sheets is already live-collaborative, so *reads* are real-time for everyone by
default. The sync question is only about *projections and notifications*:

### Real-time (seconds–minutes)
- **Assignment push:** queue generator / ops reassignment → `gws tasks tasks
  insert` into the rep's task list + `gws chat +send` to the Storm Ops space
  (`@rep 12 leads assigned — task list updated. Queue: <sheet link>`).
- **Surge alerts:** storm engine severity ≥ tier 2 → immediate Chat message
  with the storm summary and affected territory (see STORM_ENGINE.md §5).
- **SLA escalations:** status-sync job (runs every 15 min, cheap: one
  `+read` over Leads) flags `ASSIGNED` leads with no FieldActivity in
  `Config.sla_hours` → Chat mention to ops.
- **DNC:** any `DNC_REQUEST` activity → immediate suppress (Contacts.dnc,
  Lead status) on the next 15-min sync tick — worst-case minutes, and the
  queue generator re-reads dnc at build time as a second gate.
- **(Later bite)** `gws events +subscribe --project paragon-back-office` on
  Chat and Drive targets streams events over Pub/Sub for true push instead of
  the 15-min poll — the poll ships first because it has no infra dependency.

### Batched (scheduled)
| Job | Cadence | What it does |
|---|---|---|
| `status_sync` | every 15 min, 7a–9p | Form responses → FieldActivity; activity → Lead status/attempts; Tasks completion → Lead status; SLA checks |
| `queue_build` | daily 06:00 ET (+ surge re-runs) | build DailyQueue, Tasks, Calendar blocks, morning Chat summary |
| `eod_rollup` | daily 20:30 ET | DailyQueue.status_eod, per-rep scorecard to Chat, untouched leads → tomorrow's candidates |
| `contact_sync` | nightly 02:00 | Sheet ↔ People two-way (recipe-sync-contacts-to-sheet; syncToken cursor in SyncState) |
| `dashboard_rollup` | nightly 02:30 | funnel counts, conversion %, storm ROI → Dashboard tab formulas' source ranges |
| `weekly_digest` | Mon 06:30 | weekly-digest workflow pattern → Google Doc + `gws gmail +send` to ownership |
| `swdi_poller` / `forecast_poller` | see STORM_ENGINE.md | storm detection |

## 3. Notification & assignment flow (the happy path, end to end)

```
06:00  queue_build ranks top ~100 → DailyQueue rows written
06:01  per rep: gws tasks tasks insert  (title: "L-20260719-042 · 118 Porter Ave · score 87",
       notes: report URL + sheet row link, due: today)
06:02  gws calendar +insert route blocks per rep (territory cluster AM/PM)
06:03  gws chat +send → Storm Ops space: morning summary table (per-rep counts, surge flags)
06:05  gws gmail +send → ops digest email (the audit copy; threads under label Paragon/Digest)

09:40  rep knocks door → Form submit (outcome SPOKE_INTERESTED, set inspection)
09:45  status_sync: FieldActivity row → Lead status CONTACTED→INSPECT_SCHEDULED,
       gws calendar +insert inspection event on rep calendar (+ ops calendar copy),
       task patched done, Chat ping to ops only if outcome = DNC_REQUEST or ESCALATE

20:30  eod_rollup → Chat scorecard; untouched SURGE leads auto-carry to tomorrow rank-boosted
```

Reassignment mid-day is an ops edit of `Leads.assigned_rep`; the next
status_sync tick moves the Task (`tasks tasks delete` + `insert` on the new
rep's list) and Chat-notifies both reps.

## 4. Comms logging (Gmail as the system of record for outreach)

- Every outbound outreach email is sent by the comms helper:
  `gws gmail +send --to … --subject "[L-20260719-042] Roof inspection offer — 118 Porter Ave" --body <approved-template>`
  then labeled `Paragon/Outreach` and logged as a FieldActivity `EMAIL` row
  with `gmail_message_id`.
- Inbound: ops runs on `gws gmail +triage --query 'label:Paragon/Outreach is:unread'`
  (and a filter auto-labels replies by the `[L-…]` subject tag —
  recipe-create-gmail-filter pattern). A reply that needs field follow-up
  becomes a task via `gws workflow +email-to-task --message-id MSG_ID`.
- **Template discipline:** the only homeowner-facing copy the system sends is
  the operator-approved inspection-offer template stored as a Doc (ID in
  Config). Jobs interpolate name/address only. No claims about insurance
  outcomes, loan programs, or approvals — enforced by using the template
  verbatim, and a lint check in the comms helper that refuses to send if the
  body deviates from the approved template hash.

## 5. Conflict rules (why this doesn't corrupt)

1. Append-only tabs (FieldActivity, StormEvents, DailyQueue) can't conflict.
2. Mutable columns have exactly one writer class (rep columns vs. job columns
   on Leads — see DATA_MODEL.md tab 2); jobs derive status from activity, so
   a rep edit and the job converge on the same value.
3. Every job is idempotent and cursor-based (SyncState); re-running a missed
   window is safe.
4. Protected ranges + per-rep filter views keep field writes inside their lane;
   the sheet's own revision history is the audit trail of last resort.
