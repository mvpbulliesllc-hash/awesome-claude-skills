# Paragon Storm-Response Ops OS

Internal operations system for Paragon Exteriors' storm-response work on the
NJ shore, built entirely on Google Workspace + Google Cloud and driven through
the `gws` CLI. It feeds the existing roof-intel pipeline addresses, consumes
its qualified strike list, and tracks every home from flag → contact →
inspection → paperwork → job.

**Status: Phase 0 approved 2026-07-19. Decisions locked: Cloud Run + Cloud
Scheduler runner (`paragon-back-office`), `main` as default branch,
[LOCKS.md](LOCKS.md) keys policy, Sheets→Postgres graduation path
(ARCHITECTURE.md §6). Building from Bite 1; Bite 0 closes when the service
account credential lands in the runner environment.**

| Doc | What it covers |
|---|---|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Component map (which Google surface is which part of the system), data-flow diagram, trust boundaries, the open scheduler decision |
| [DATA_MODEL.md](DATA_MODEL.md) | The Sheets schema that is the CRM — every tab, every column; strike-list writeback contract; field read/write paths |
| [SYNC_MODEL.md](SYNC_MODEL.md) | How field ↔ ops ↔ ownership stay in sync: real-time vs. batched, notification/assignment flow via Gmail/Chat/Tasks |
| [STORM_ENGINE.md](STORM_ENGINE.md) | Pre-storm early warning + post-storm surge triggers (NOAA SWDI + NWS), severity tiers, queue generation |
| [BUILD_PLAN.md](BUILD_PLAN.md) | The system in small shippable bites, each with a definition of done and a live-verifiable checkpoint |

Interface spec consumed (not rebuilt) by this OS:
[`.claude/skills/roof-scan-qualify/SKILL.md`](.claude/skills/roof-scan-qualify/SKILL.md)
— the tiered qualification funnel that produces the daily ~100-home strike list.

Hard constraints held throughout: Workspace/Cloud only for the ops layer;
internal tool — no homeowner-facing claims about loan programs or insurance
outcomes, outreach copy is roof condition + inspection offer only; all
secrets via environment variables.
