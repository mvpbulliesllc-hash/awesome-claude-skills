# ARCHITECTURE — Paragon Storm-Response Ops OS

**Phase 0 design document. No code ships until this is approved.**

Paragon's ops OS is built entirely on Google Workspace + Google Cloud, driven
through the `gws` CLI (Discovery-based, structured JSON — never hand-wired REST).
Every component below maps to a Google surface the team already lives in. The
"application" is a thin layer of idempotent gws-driven jobs plus conventions
(schemas, IDs, labels, folder trees) that make those surfaces behave like a CRM.

---

## 1. Principles

1. **Sheets is the system of record.** One master spreadsheet is the CRM
   database. Everything else (Tasks, Chat, Calendar, Gmail labels) is a
   *projection* of sheet state, regenerable from it.
2. **Append-only where humans write fast.** Field activity, comms logs, and
   storm events are append-only logs (`gws sheets +append`). Mutable state
   (lead status, assignments) lives in single-writer columns updated by jobs
   or by controlled field inputs (Forms / filtered views).
3. **Idempotent jobs, replayable inputs.** Every scheduled job can be re-run
   safely: upserts key on stable IDs, pollers persist cursors in a SyncState
   tab, and storm detection can be replayed against historical NOAA data.
4. **gws only, env vars only.** All Workspace/Cloud access goes through `gws`
   (auth via `gws auth login` or `GOOGLE_APPLICATION_CREDENTIALS`). API keys
   (e.g. `GOOGLE_MAPS_API_KEY`) come from the environment — never committed,
   never hardcoded in scripts, docs, or HTML samples. *(Note: the sample
   Aerial View HTML circulating with the mission brief contains a hardcoded
   `AIzaSy…` key — that key should be rotated and the file scrubbed before it
   lands anywhere shared.)*
5. **Internal tool, held line.** The system never generates homeowner-facing
   claims about loan programs, insurance outcomes, or guaranteed approvals.
   The only outreach copy it produces is templated "roof condition +
   inspection offer" text, reviewed once by a human and then reused verbatim.
6. **Don't rebuild roof-intel.** The existing pipeline
   (geocode → Solar → NOAA hail → vision → composite score → report page)
   stays as-is. This OS *feeds it addresses* and *consumes its strike list*.

---

## 2. Component map — which Google surface is which part of the system

| System role | Google surface | How it's driven |
|---|---|---|
| CRM database (leads, properties, deals, storm events, activity, queue) | **Google Sheets** — one master spreadsheet, `Paragon Ops CRM` | `gws sheets +read / +append / spreadsheets.batchUpdate` (recipe-log-deal-update pattern) |
| Document store (roof-intel PDFs, photos, contracts, report pages) | **Google Drive** — canonical folder tree, one folder per property | `gws drive +upload`, `gws drive files list --params '{"q": …}'` |
| Logged comms (internal-approved outreach, homeowner replies) | **Gmail** — label taxonomy + subject-line lead tags | `gws gmail +send / +triage / +reply`, `gws workflow +email-to-task` |
| Field scheduling (inspection appts, route blocks) | **Calendar** — one calendar per rep + `Storm Ops` master calendar | `gws calendar +insert`, `+agenda` |
| Contacts (homeowners, adjusters-of-record, vendors) | **People** — synced two-way with the Contacts tab | `gws people people createContact / connections list` (recipe-sync-contacts-to-sheet pattern) |
| Assignment queue (what each rep owes today) | **Tasks** — one task list per rep | `gws tasks tasks insert/list/patch` |
| Real-time notifications (assignments, storm alerts, SLA escalations) | **Chat** — `Storm Ops` space (+ per-storm threads) | `gws chat +send`, `gws events +subscribe` (Pub/Sub in `paragon-back-office`) |
| Field data capture (door-knock outcomes, inspection results) | **Forms** → FieldActivity tab | recipe-collect-form-responses pattern |
| Ownership reporting (pipeline, conversion, storm ROI) | **Sheets** Dashboard tab + **Docs** weekly digest | `gws docs +write`, `gws workflow +weekly-digest` pattern |
| Geospatial services (geocode, address validation, routes, street view) | **Google Cloud** project `paragon-back-office` | `GOOGLE_MAPS_API_KEY` from env (used by roof-intel + route ordering) |
| Storm data | **NOAA SWDI** (keyless hail) + **api.weather.gov** (keyless forecast/alerts) | storm-engine poller jobs (see STORM_ENGINE.md) |
| Event plumbing for near-real-time sync | **Pub/Sub** in `paragon-back-office` | `gws events +subscribe --project paragon-back-office` |

The compute that runs the jobs (pollers, queue generator, sync jobs) is a small
runner executing gws commands on a schedule. *Where* that runner lives is the
Phase 0 open decision — see §5.

---

## 3. Data flow (text diagram)

```
                    ┌────────────────────────────────────────────────┐
                    │                 STORM ENGINE                   │
                    │  NWS forecast/alerts        NOAA SWDI hail     │
                    │  (pre-storm trigger)        (post-storm trigger)│
                    └───────────┬────────────────────────┬───────────┘
                                │ StormEvents row        │ StormEvents row
                                ▼                        ▼
   address discovery      ┌──────────────────────────────────┐
   (swath → parcels/      │   MASTER SHEET  "Paragon Ops CRM"│
    Places, existing ─────►   Properties / Leads / Contacts  │
    book of record)       │   Deals / StormEvents /          │
                          │   FieldActivity / DailyQueue     │
                          └───────┬──────────────▲───────────┘
        feed addresses ───────────┘              │ strike list writeback
                ▼                                │ (score + report URL)
   ┌─────────────────────────┐          ┌────────┴────────────┐
   │  ROOF-INTEL PIPELINE    │          │ Drive: /Properties/ │
   │  (existing — geocode →  ├─────────►│  <prop_id>/reports, │
   │  Solar → hail → vision →│  PDFs    │  photos, contracts  │
   │  composite score →      │          └─────────────────────┘
   │  report page)           │
   └─────────────────────────┘

   DAILY QUEUE GENERATOR (06:00 ET)
   Sheet (Properties×Leads×StormEvents) → rank → top ~100 → DailyQueue tab
        ├─► Tasks: one task per queued lead, per-rep task list
        ├─► Calendar: route blocks / inspection slots per rep
        ├─► Chat: morning assignment summary to Storm Ops space
        └─► Gmail: ops digest to coordinators + ownership

   FIELD LOOP (all day)
   Rep phone: Tasks (what) + Sheets filtered view (context) + Calendar (when)
        └─► Form submit → FieldActivity append → status-sync job → Leads status
                                             └─► Chat escalations (SLA breaches)

   OWNERSHIP LOOP
   Nightly rollup job → Dashboard tab;  weekly digest job → Doc + Gmail
```

---

## 4. Trust & write boundaries

| Actor | Can write | Cannot write |
|---|---|---|
| Storm engine / queue generator (service account) | StormEvents, DailyQueue, Leads (create + assign), Properties (upsert), Tasks, Calendar, Chat | FieldActivity (human log), Deals financials |
| Field reps | Forms → FieldActivity; whitelisted columns on their filtered Leads view (status, outcome, notes); Task complete; Calendar RSVP | Any other tab; other reps' rows |
| Ops coordinators | Everything in the sheet; Gmail outreach sends (templated only) | — |
| Ownership | Read everywhere; Config (thresholds, territories) | Operational rows (by convention) |

All writes by jobs go through gws with `--dry-run` in staging mode first; the
gws-shared security rule ("confirm before write") is honored in development by
requiring an operator flag before any job runs in `--live` mode during Bites 1–5.

---

## 5. Scheduler/runner — **DECIDED (operator approval, 2026-07-19)**

**Cloud Run job + Cloud Scheduler in `paragon-back-office`.** Containerized
gws runner with a service-account credential (`GOOGLE_APPLICATION_CREDENTIALS`,
domain-wide delegation limited to the scopes in §2); jobs fire on cron; logs
in Cloud Logging; survives laptops being closed.

Rejected alternatives, for the record: an always-on operator box (ops stops
when the box sleeps — acceptable only as a Bites 1–7 stopgap, and manual
triggers cover that anyway) and Apps Script triggers (abandons the gws
discipline, 6-min execution ceiling).

Everything in BUILD_PLAN.md is runner-agnostic through Bite 7 (manual
trigger); the runner container + scheduler wiring land with Bite 8.
Credential provisioning (service account key into the runner env, never the
repo — see LOCKS.md) is the operator step that closes Bite 0.

---

## 6. Scale ceiling & the Postgres graduation (known, planned — not a surprise)

Sheets-as-CRM is the correct pilot call: fast, visible, gws-native, ops can
eyeball every row. It has a known ceiling — Sheets degrades and gets
lock-prone in the low tens of thousands of hot rows and under heavy
concurrent writes. The pilot sits comfortably under it (~30k leads/yr,
appends batched through jobs, field writes funneled via Forms).

**Graduation triggers — hit any one and the migration bite gets scheduled:**
- FieldActivity + DailyQueue combined exceed ~200k live rows despite archiving
- `status_sync` p95 run time exceeds 60s, or visible sheet lag for ops
- sustained multi-town scanning pushes past ~2,500 new leads/week
- concurrent field writers regularly collide (protected-range write failures)

**Graduation path (pre-committed shape, so it's a lift-and-shift not a
redesign):** the data layer moves to Postgres (Neon); the master sheet
becomes a *generated human-facing view* (jobs project Postgres → per-rep and
dashboard tabs, same UX for the field); Tasks/Chat/Calendar/Gmail projections
are untouched because they already read through the access layer. The swap
seam is deliberate: **only `ops/lib` helpers touch storage** (Bite 2), every
tab has stable IDs + append-only semantics that map 1:1 to tables, and
SyncState cursors carry over. Migration = replay tabs into tables, flip
helpers' backend, keep Sheets as the view. Tracked as a named future bite in
BUILD_PLAN.md §Bite 11+.
