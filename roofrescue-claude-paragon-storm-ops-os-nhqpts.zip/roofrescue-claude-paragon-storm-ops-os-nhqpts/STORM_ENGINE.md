# STORM_ENGINE — Pre-Storm Early Warning + Post-Storm Surge

**Phase 0 design document.**

The storm engine is the trigger layer. It watches keyless government feeds,
writes `StormEvents` rows, decides *where and when* to run the
**roof-scan-qualify** funnel (`.claude/skills/roof-scan-qualify/SKILL.md`),
and hands the qualified output to the daily queue. It does not score roofs
itself — ranking and the qualification bar belong to the funnel; the engine
supplies the *area + storm overlay + urgency*.

Paragon's edge is the two windows competitors miss: the day *before* a storm
(pre-position, offer pre-storm documentation inspections) and the hours
*after* (reach hit homes before competitors and before the carrier's
non-renewal machinery reacts).

---

## 1. Data sources (all keyless)

| Feed | What | Poll cadence |
|---|---|---|
| **NOAA SWDI `nx3hail`** (proven in roof-intel) | radar-detected hail signatures: lat/lng, time, max size | hourly baseline; **every 15 min** while a WATCH window is open |
| **api.weather.gov `/alerts/active`** | Severe Thunderstorm / Tornado / High Wind watches & warnings by NJ zone (Ocean, Monmouth, Atlantic coastal zones from Config) | every 30 min |
| **SPC convective outlooks** (Day 1–2, api.weather.gov products) | categorical risk ≥ SLGT over the territory → opens a WATCH window a day early | 2×/day (~07:00, ~17:00) |

Pollers are cursor-based (`SyncState.cursor` = last-seen event ts / alert id),
idempotent (dedupe on `StormEvents.raw_ref`), and replayable against
historical dates for testing.

## 2. Trigger logic

```
FORECAST (pre-storm):
  SPC outlook ≥ SLGT over territory  OR  NWS watch issued for a Config zone
    → StormEvent{type=FORECAST, severity per §3}
    → open WATCH window (SWDI poller drops to 15-min cadence)
    → PRE-STORM SWEEP queue for next morning (see §4)

DETECTION (post-storm):
  new SWDI nx3hail rows intersect territory bbox
    → cluster rows within 10 km / 30 min into one StormEvent{type=HAIL}
    → severity per §3; swath = union of hail points buffered 1.5 km
    → spatial match: Properties within swath → last_storm_id, hail_hits_12mo++
    → invoke roof-scan-qualify (area = swath polygon, storm overlay = this
      event, N from Config) — the funnel's tiered gates keep cost sane even
      on a big swath (its guardrail: >~500 vision scans ⇒ tighten Stage 1)
    → SURGE queue build (same-day if severity ≥ 2, else next 06:00)
```

`StormEvents.queue_generated` is the idempotency latch — a re-run of the
poller never double-builds a queue for the same event.

## 3. Severity tiers

| Tier | Condition (any) | Response |
|---|---|---|
| 3 — SURGE | hail ≥ `Config.surge_hail_in` (1.0") in territory; or warning-verified wind ≥ 60 mph | immediate Chat alert; same-day re-queue; all reps; capacity caps lifted |
| 2 — HIGH | hail 0.75–1.0"; SVR warning polygon over territory | Chat alert; next-morning queue prioritizes swath; `priority=HIGH` |
| 1 — WATCH | SPC ≥ SLGT; SVR watch; hail < 0.75" | pre-storm sweep; faster polling; no rep interrupt |

## 4. What a trigger actually does (queue generation)

The 06:00 `queue_build` (and surge re-runs) assembles the day's ~100 from
three buckets, in priority order:

1. **POST_STORM** — the roof-scan-qualify output for any storm event in the
   last 72 h with `queue_generated=FALSE`. These arrive already ranked and
   already over the qualification bar; the queue takes them top-down.
2. **PRE_STORM** — when a FORECAST event is open: highest cold-score
   (funnel Stage 1 only — no imagery spend) unworked properties in threatened
   zips. Reps offer pre-storm roof-condition documentation inspections —
   same approved template, same licensing line.
3. **AGING / FOLLOW_UP** — leads with `next_action_date <= today`, then
   qualified-but-never-queued backlog, until the queue reaches
   `Config.queue_size` — *but only with roofs that cleared the bar; the queue
   runs short rather than padded* (funnel guardrail inherited here).

Suppression gates (applied last, always): `Contacts.dnc=TRUE`,
lead status in {WON, LOST, DNC}, contacted within `Config.recontact_days`.

Then: territory-balance across active reps by `daily_capacity`, write
`DailyQueue`, create Tasks, Calendar route blocks, Chat morning summary,
ops digest email (flow detailed in SYNC_MODEL.md §3).

## 5. Notifications

- **Tier 3:** `gws chat +send` immediately: storm summary (max hail, zips,
  property count, map link), then queue rebuild announcement when done.
- **Tier 2:** Chat alert; queue changes land with the normal morning summary.
- **Pre-storm (evening before):** Chat + ops email: "SLGT risk tomorrow for
  OCEAN-N; pre-storm sweep queued: 40 homes; SWDI polling at 15-min."
- Every alert includes the `storm_id` so field chatter threads under it.

## 6. Cost & honesty guardrails (inherited from roof-scan-qualify)

- Vision never runs on a full pool — the engine passes areas, the funnel's
  staged gates control per-roof spend; projected spend is reported before any
  full-area run (pilot one town, extrapolate, then scale).
- Every roof-intel/API response is cached by address+imagery-date, so storm
  re-runs over the same swath are nearly free.
- The queue is never padded with unqualified roofs. Short honest list > 100
  padded rows — reps burn trust knocking on clean roofs, and the ground-truth
  loop (door-knock outcomes in FieldActivity vs. vision flags) is the dial
  that tunes the qualification bar over time. That feedback join
  (FieldActivity outcomes × Leads.score × flags) is a standing Dashboard view.
