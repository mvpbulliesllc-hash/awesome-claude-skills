# DATA_MODEL — The Sheets Schema That Is The CRM

**Phase 0 design document.**

One master spreadsheet: **`Paragon Ops CRM`** (Drive folder `/Paragon Ops/`).
Ten tabs. All programmatic access via `gws sheets +read`, `gws sheets +append`
(with `--json-values` for bulk), and `spreadsheets.batchUpdate` for structured
edits. Header row = row 1, frozen; jobs address columns by header name, never
by letter, so columns can be appended without breaking jobs.

Scale check: ~100 leads/day × 300 storm-season days ≈ 30k leads/yr; with
activity at ~5 rows/lead that's well inside the 10M-cell Sheets limit for
2–3 years. Archive policy in §12; the explicit Sheets→Postgres graduation
triggers and path live in ARCHITECTURE.md §6.

## ID conventions

| Entity | Format | Example | Minted by |
|---|---|---|---|
| Property | `P-` + 6-digit seq | `P-000118` | ingest job (keyed on `place_id`) |
| Lead | `L-YYYYMMDD-` + 3-digit seq | `L-20260719-042` | queue/ingest job |
| Contact | `C-` + 6-digit seq | `C-000034` | contact sync job |
| Deal | `D-` + 4-digit seq | `D-0007` | ops, via helper |
| Storm event | `S-YYYYMMDD-` + type + seq | `S-20260718-HAIL-01` | storm engine |
| Activity | `A-` + ULID-style timestamp id | `A-20260719T1432-7f3` | form/logging helper |

`place_id` (Google Address Validation / Geocoding) is the natural key for
properties; the sequence IDs exist so humans can say them out loud.

---

## Tab 1 — `Properties` (the home universe; upsert, one row per roof)

| Col | Field | Type / enum | Notes |
|---|---|---|---|
| A | property_id | `P-######` | stable |
| B | place_id | string | **unique key**; from Address Validation |
| C | address | string | normalized single-line |
| D | street / E city / F zip | strings | split for territory filters |
| G | lat / H lng | decimal | from geocode |
| I | territory | enum (e.g. `OCEAN-N`, `OCEAN-S`, `MONMOUTH`) | assigned from zip via Config map |
| J | roof_score | 0–100 | composite score from roof-intel |
| K | score_date | ISO date | last scored |
| L | roof_age_est | years | from roof-intel vision |
| M | roof_material | enum `ASPHALT/METAL/FLAT/TILE/UNKNOWN` | |
| N | est_squares | number | from Solar geometry stage (accuracy target: within a few % of RoofScope ground truth — 118 Porter Ave: 26.04 SQ, 9 planes) |
| N2 | top_flags | string | vision flags w/ confidence, e.g. `tarp:0.9, creased:0.7` |
| O | intel_report_url | URL | roof-intel report page (built from `report_slug`; generated only for qualified roofs) |
| P | report_pdf_id | Drive file ID | e.g. RoofScope+/intel PDF in property folder |
| Q | drive_folder_id | Drive folder ID | `/Paragon Ops/Properties/P-######/` |
| R | last_storm_id | `S-…` | most recent StormEvent that hit it |
| S | hail_hits_12mo | int | SWDI matches, trailing 12 months |
| T | nonrenewal_risk | enum `LOW/MED/HIGH` | proxy: age + hits + coastal zone |
| U | status | enum `UNTOUCHED/QUEUED/WORKING/CUSTOMER/DNC/DEAD` | rollup from Leads |
| V | source | enum `STRIKE_LIST/SWATH_DISCOVERY/MANUAL/REFERRAL` | |
| W | first_seen / X updated_at / Y updated_by | ISO ts / email | job or human |

**Strike-list writeback contract (roof-scan-qualify → this tab):** the
qualification funnel (`.claude/skills/roof-scan-qualify/SKILL.md` — Stage 0
enumerate → cold score → Solar geometry → vision damage pass → qualification
bar) emits one JSON line per **qualified** roof:
`{place_id, address, owner, lat, lng, composite_score,
flags: [{name, confidence}], storm_summary, est_squares, report_slug}`.
Only roofs that clear the bar arrive here — the funnel never pads to N.
The ingest job:
1. `gws sheets +read --spreadsheet $CRM_ID --range "Properties!B:B"` → build
   place_id index.
2. New place_id → mint `P-######`, `gws drive` create property folder, upload
   PDF (`gws drive +upload report.pdf --parent $FOLDER`), append full row
   (`+append --range "Properties!A1" --json-values '[[…]]'`).
3. Existing → `batchUpdate` only score/report/date columns (J,K,O,P,X,Y).

## Tab 2 — `Leads` (one row per pursuit of one property; the working table)

| Col | Field | Type / enum |
|---|---|---|
| A | lead_id | `L-YYYYMMDD-###` |
| B | property_id | FK → Properties |
| C | contact_id | FK → Contacts (blank until identified) |
| D | queue_date | ISO date first queued |
| E | storm_id | FK → StormEvents (blank for aging/pre-storm leads) |
| F | score | number — queue rank score at creation (see STORM_ENGINE.md §4) |
| G | priority | enum `SURGE/HIGH/STANDARD` |
| H | assigned_rep | rep email |
| I | status | enum `NEW → ASSIGNED → ATTEMPTED → CONTACTED → INSPECT_SCHEDULED → INSPECTED → PROPOSAL_SENT → WON / LOST / DNC / STALE` |
| J | status_ts | ISO ts of last status change |
| K | attempts | int (door + call + mail total) |
| L | next_action | short text |
| M | next_action_date | ISO date — drives SLA + re-queue |
| N | task_id | Google Tasks id of current assignment task |
| O | calendar_event_id | inspection event, when scheduled |
| P | notes | free text (reps write here) |
| Q | created_at / R updated_at / S updated_by | |

Status transitions are written by: reps (via Form/filtered view: I,L,M,P),
the status-sync job (I,J,N,O from activity + Tasks), never both on the same
column at once — the job only advances status from activity rows, so a rep
edit and a job edit converge.

## Tab 3 — `Contacts` (people; synced two-way with Google People)

| Col | Field | Notes |
|---|---|---|
| A | contact_id | `C-######` |
| B | property_id | FK (primary residence) |
| C | full_name | |
| D | phone / E email | |
| F | preferred_channel | `DOOR/PHONE/EMAIL/MAIL` |
| G | dnc | bool — **hard suppress**: no queue, no outreach, ever |
| H | consent_notes | how/when contact info was obtained |
| I | people_resource | `people/c123…` — People API resourceName (sync key) |
| J | source / K notes / L updated_at | |

Sync: recipe-sync-contacts-to-sheet pattern, run nightly both directions —
sheet rows lacking `people_resource` → `gws people people createContact`;
People changes pulled via `connections list` with `syncToken` (cursor in
SyncState). Reps thereby get homeowner contacts on their phones natively.

## Tab 4 — `Deals` (post-inspection commercial pipeline)

| Col | Field | Notes |
|---|---|---|
| A | deal_id | `D-####` |
| B | lead_id / C property_id | FKs |
| D | stage | enum `PROPOSAL → SIGNED → PERMITTING → SCHEDULED → IN_PROGRESS → COMPLETE → PAID → CLOSED` |
| E | value_est | USD |
| F | contract_pdf_id | Drive |
| G | crew | text |
| H | start_date / I end_date | |
| J | notes / K updated_at / L updated_by | |

Written by ops via the log-deal-update pattern
(`gws sheets +append` a stage-change row is *not* used here — Deals is
upsert; stage history lives in FieldActivity rows of type `DEAL_STAGE`).

## Tab 5 — `StormEvents` (append-only; what the storm engine saw)

| Col | Field | Notes |
|---|---|---|
| A | storm_id | `S-YYYYMMDD-TYPE-##` |
| B | type | `HAIL / WIND / FORECAST` |
| C | source | `SWDI:nx3hail / NWS:alert / SPC:outlook` |
| D | event_ts | when it happened (or forecast valid time) |
| E | detected_ts | when the poller saw it |
| F | bbox_or_zone | bbox string or NWS zone id (`NJZ026`) |
| G | max_hail_in | number (hail) |
| H | severity_tier | 1–3 (see STORM_ENGINE.md §3) |
| I | zips_hit | comma list |
| J | properties_hit | int (after spatial match) |
| K | queue_generated | bool — idempotency latch |
| L | raw_ref | SWDI row key / alert id — dedupe key |
| M | notes | |

## Tab 6 — `FieldActivity` (append-only event log; never edited)

| Col | Field | Notes |
|---|---|---|
| A | activity_id | `A-…` |
| B | ts | ISO |
| C | rep | email |
| D | lead_id / E property_id | FKs |
| F | type | `DOOR_KNOCK / CALL / EMAIL / INSPECTION / PHOTO_UPLOAD / NOTE / STATUS_CHANGE / DEAL_STAGE` |
| G | outcome | `NO_ANSWER / SPOKE_INTERESTED / SPOKE_NOT_NOW / DNC_REQUEST / SET_INSPECTION / COMPLETED / …` |
| H | notes | |
| I | gmail_message_id | when type=EMAIL (links the logged comm) |
| J | photo_folder_id | when photos uploaded |
| K | gps_lat / L gps_lng | from Form (optional) |
| M | entered_via | `FORM / SHEET / JOB` |

Populated by: the field Google Form (recipe-collect-form-responses — Form
responses land in a linked response sheet; a mover job normalizes rows into
this tab), the comms logger, and jobs. `DNC_REQUEST` outcome triggers the
status-sync job to set Contacts.dnc=TRUE and Lead status=DNC immediately.

## Tab 7 — `DailyQueue` (regenerated each morning; the day's marching orders)

| Col | Field | Notes |
|---|---|---|
| A | queue_date | ISO date |
| B | rank | 1..N (N≈100) |
| C | lead_id / D property_id | FKs |
| E | address | denormalized for the field view |
| F | score | rank score |
| G | reason | `POST_STORM / PRE_STORM / AGING / FOLLOW_UP` |
| H | storm_id | FK or blank |
| I | assigned_rep | email |
| J | route_order | int within rep (Routes API ordering, later bite) |
| K | task_id | created Tasks id |
| L | status_eod | filled by evening rollup: `DONE / ATTEMPTED / UNTOUCHED` |

Rows for prior days are never deleted (the tab doubles as queue history);
each rep's mobile filtered view shows `queue_date = today AND assigned_rep = me`.

## Tab 8 — `Reps`

rep_id, name, email, phone, territory (multi, comma list), tasklist_id,
calendar_id, chat_member, daily_capacity (default 25), active (bool).

## Tab 9 — `Config` (key/value)

`queue_size=100`, `surge_hail_in=1.0`, score weights, territory→zip map rows,
`chat_space=spaces/AAAA…`, `crm_folder_id`, SLA hours, outreach template doc IDs.
Jobs read Config at start of every run — no constants in code.

## Tab 10 — `SyncState` (job ledger + cursors; append + upsert)

| Col | Field | Notes |
|---|---|---|
| A | job_name | e.g. `swdi_poller` |
| B | last_run_ts / C ok | heartbeat |
| D | cursor | SWDI last-seen ts, People syncToken, Form last-row |
| E | rows_in / F rows_out / G error | run stats |

---

## 11. How field reps read/write (mobile reality)

- **Read:** Google Sheets app → `DailyQueue` and `Leads` per-rep **filter
  views** (created via `batchUpdate` addFilterView, one per rep); Tasks app
  for the to-do list; Calendar for appointments; report PDFs open from the
  `intel_report_url` / Drive links in the queue row.
- **Write:** the **Field Activity Form** (30-second door-knock logging:
  lead picker, outcome, notes, photos) — this is the primary write path and
  keeps FieldActivity append-only. Direct sheet edits are limited by
  protected ranges to Leads cols I,L,M,P on their own rows.

## 12. Archive policy

Every Jan 2: copy-sheet-for-new-month pattern at yearly grain — duplicate the
workbook to `Paragon Ops CRM — <year> archive` (`gws drive files copy`), then
delete FieldActivity/DailyQueue/StormEvents rows older than 13 months from the
live book. Properties/Contacts/Deals never archive (they're the book of record).
