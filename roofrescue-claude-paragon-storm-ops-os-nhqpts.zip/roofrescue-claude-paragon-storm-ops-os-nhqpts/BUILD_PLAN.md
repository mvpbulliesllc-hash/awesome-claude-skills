# BUILD_PLAN — Small Shippable Bites, Each Live-Verifiable

**Phase 0 design document.** Ordered by dependency. Every bite has a
definition of done (DoD) and a checkpoint an operator can verify against the
*live* Workspace account in under five minutes. No bite starts until the
previous checkpoint passes. Bites 1–7 are runner-agnostic (manual trigger);
the scheduler decision (ARCHITECTURE.md §5) gates Bite 8+.

Repo layout as bites land: `ops/` (job scripts, gws-driven), `templates/`
(approved outreach copy + digest formats), `.claude/skills/` (project skills,
incl. `roof-scan-qualify`), `docs/` (these files move here post-approval).

---

### Bite 0 — Preflight
Verify `gws` auth + project wiring. Nothing created.
- **DoD:** `gws auth login` (or service-account env) done; `gws gmail users
  getProfile --params '{"userId":"me"}'` and `gws drive files list --params
  '{"pageSize":1}'` both return clean JSON; `GOOGLE_MAPS_API_KEY` present in
  env (never echoed).
- **Checkpoint:** operator runs both commands, sees their own account.

### Bite 1 — Workspace scaffold
Create the surfaces: `Paragon Ops CRM` spreadsheet with all 10 tabs +
frozen header rows (per DATA_MODEL.md), `/Paragon Ops/` Drive tree
(`/Properties/`, `/Storms/`, `/Templates/`, `/Digests/`), `Storm Ops` Chat
space, Gmail labels (`Paragon/Outreach`, `Paragon/Digest`), per-rep task
lists + calendars, Reps + Config seeded. All IDs recorded in Config tab and
`.env.example`.
- **DoD:** scaffold script is idempotent (re-run finds, not duplicates —
  keyed on `drive files list` name queries).
- **Checkpoint:** `gws sheets +read --spreadsheet $CRM_ID --range
  "Properties!1:1"` shows the exact header row; Chat space visible in the
  operator's Chat app; second run of the script creates nothing new.

### Bite 2 — CRM helpers (the data access layer)
`ops/lib`: ID minting, header-name→column resolution, upsert-by-key
(read index → append or batchUpdate), SyncState heartbeat/cursor read-write.
- **DoD:** unit-style dry runs with `--dry-run`; helper CLI:
  `ops/crm append-lead …`, `ops/crm set-status L-… CONTACTED`.
- **Checkpoint:** operator appends a fake lead, sets its status, sees both in
  the sheet UI, and SyncState shows the two runs.

### Bite 3 — Strike-list ingest (the roof-intel writeback)
Consume roof-scan-qualify JSONL (contract in DATA_MODEL.md tab 1):
Properties upsert, property Drive folder + PDF upload, Leads creation.
- **DoD:** idempotent on `place_id`; malformed rows quarantined to a
  `rejects.jsonl` with reasons, never silently dropped.
- **Checkpoint:** run against a hand-built 3-row sample including
  118 Porter Ave (26.04 SQ, 9 planes, its RoofScope PDF as the report
  artifact); operator opens the property folder in Drive and sees the PDF,
  and the Properties row links everything.

### Bite 4 — Daily queue generator (manual trigger)
`ops/queue build [--date …]`: three buckets + suppression gates + territory
balancing per STORM_ENGINE.md §4; writes DailyQueue.
- **DoD:** honest-list rule enforced (short > padded); DNC suppression has a
  test; re-run for same date replaces cleanly (idempotency latch).
- **Checkpoint:** with ~20 seeded leads across 2 fake reps, operator runs it
  and sees a ranked, balanced DailyQueue tab; a DNC-flagged contact's
  property provably absent.

### Bite 5 — Assignment & notify
Queue rows → Tasks (per-rep list, report link in notes), Calendar route
blocks, Chat morning summary, ops digest email.
- **DoD:** all four projections built from DailyQueue alone (regenerable);
  reassignment helper moves the Task and pings both reps.
- **Checkpoint:** operator's phone shows the task in Google Tasks, the
  calendar block, and the Chat summary — the full field-facing morning, live.

### Bite 6 — Field capture loop
Field Activity Form (lead picker, outcome enum, notes, photos) + response
mover → FieldActivity; `status_sync` job (manual trigger this bite): activity
→ Lead status, inspection outcome → Calendar event, DNC → immediate suppress;
per-rep filter views + protected ranges on Leads/DailyQueue.
- **DoD:** DNC path proven end-to-end; protected ranges block an off-lane
  edit in the sheet UI.
- **Checkpoint:** operator submits the Form from a phone as a fake rep;
  within one `status_sync` run the lead advances and the inspection appears
  on the calendar.

### Bite 7 — Logged comms
Approved-template outreach sender (template hash lint per SYNC_MODEL.md §4),
`[L-…]` subject tagging, `Paragon/Outreach` labeling, FieldActivity EMAIL
rows, reply triage query + email-to-task escalation.
- **DoD:** sender refuses a modified body (hash mismatch); every send is
  logged with `gmail_message_id`.
- **Checkpoint:** send to an internal test inbox; `gws gmail +triage --query
  'label:Paragon/Outreach'` finds it; the activity row links the message id;
  a doctored template is rejected.

### Bite 8 — Storm engine: post-storm (needs scheduler decision)
SWDI `nx3hail` poller (cursor, dedupe, clustering) → StormEvents; swath
spatial match against Properties; roof-scan-qualify invocation on the swath;
severity tiers + surge Chat alerts; queue integration (POST_STORM bucket).
- **DoD:** fully replayable: `ops/storm replay --date YYYY-MM-DD` against a
  known historical NJ hail day produces the same StormEvents twice (latch
  holds).
- **Checkpoint:** operator replays a historical hail day and watches:
  StormEvents rows, matched properties, surge Chat alert (to a test space),
  and a queue build sourced from the event.

### Bite 9 — Storm engine: pre-storm
NWS alerts + SPC outlook pollers → FORECAST events; WATCH-window fast
polling; pre-storm sweep bucket (Stage-1-only cold scores, no imagery
spend); evening-before notifications.
- **DoD:** replayable from recorded alert JSON; sweep provably spends zero
  imagery/vision calls.
- **Checkpoint:** simulate a SLGT day from a fixture; evening Chat/email
  fires; next morning's queue contains the PRE_STORM bucket.

### Bite 10 — Scheduler + steady-state sync
All jobs on cadence (SYNC_MODEL.md §2 table) on the chosen runner; SLA
escalations; nightly People contact sync; EOD rollup; Dashboard tab; weekly
digest Doc + email; SyncState heartbeat alerting (job silent > 2× cadence →
Chat warning).
- **DoD:** 48-hour unattended soak with all heartbeats green.
- **Checkpoint:** operator does nothing for two days, then reads the Monday
  digest email and a green SyncState tab.

### Bite 11+ — Deliberately deferred
Route optimization (Routes API ordering in DailyQueue), `gws events
+subscribe` Pub/Sub push replacing the 15-min poll, EagleView verified-tier
enrichment, qualification-bar auto-tuning from door-knock ground truth,
yearly archive automation, and the **Postgres graduation** — when any
trigger in ARCHITECTURE.md §6 fires, the data layer moves to Postgres
(Neon) and Sheets becomes the generated human-facing view; the `ops/lib`
seam from Bite 2 exists precisely so this is a backend swap, not a redesign.

---

## Dependency graph

```
0 → 1 → 2 → 3 → 4 → 5 → 6 → 7
                    └────────── (scheduler decision) → 8 → 9 → 10 → 11+
```

Bites 6–7 and 8–9 can proceed in parallel once 5 lands, if two builders are
available; 10 requires everything before it.
