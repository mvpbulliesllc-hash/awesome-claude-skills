import { defineTool } from "eve/tools";
import { z } from "zod";
import { isDriveConfigured, listFiles } from "../../lib/drive";

export default defineTool({
  description:
    "List files and folders in the user's Google Drive. Pass a folder ID to browse into it, or omit to list the Drive root. Returns each file's id, name, mimeType, size, modifiedTime, and webViewLink (the shareable/download link).",
  inputSchema: z.object({
    folder: z
      .string()
      .optional()
      .describe("Google Drive folder ID to list. Omit for the root folder."),
  }),
  async execute({ folder }) {
    if (!isDriveConfigured()) {
      return {
        configured: false,
        message:
          "Google Drive is not connected. Ask the user to visit /api/auth/google and set GOOGLE_REFRESH_TOKEN.",
      };
    }
    const listing = await listFiles(folder ?? "root");
    return { configured: true, ...listing };
  },
});
