import { once } from "eve/tools/approval";
import { defineTool } from "eve/tools";
import { z } from "zod";
import { callTool } from "../../lib/mcp";

export default defineTool({
  description:
    "Invoke a tool on an automation MCP server — Arcads (generate AI video ads) or n8n (trigger a workflow). Use list_automation_tools first to get the exact tool name and its argument schema, then call it here. Example: generate an Arcads video, or trigger an n8n content pipeline.",
  inputSchema: z.object({
    service: z
      .enum(["arcads", "n8n"])
      .describe("Which MCP server hosts the tool."),
    tool: z
      .string()
      .min(1)
      .describe("Exact tool name from list_automation_tools."),
    arguments: z
      .record(z.string(), z.unknown())
      .default({})
      .describe("Arguments object matching the tool's input schema."),
  }),
  // Triggering generation jobs / workflows has external side effects and can
  // consume credits — gate the first call of a session on human approval.
  needsApproval: once(),
  async execute({ service, tool, arguments: args }) {
    const data = await callTool(service, tool, args);
    return { service, tool, data };
  },
});
