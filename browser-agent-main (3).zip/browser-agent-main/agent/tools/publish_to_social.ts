import { once } from "eve/tools/approval";
import { defineTool } from "eve/tools";
import { z } from "zod";
import { publishToSocial, SUPPORTED_PLATFORMS } from "../../lib/composio";

export default defineTool({
  description:
    "Publish a caption (and optional media URL) to one or more social platforms via Composio. Supported platforms: instagram, tiktok, twitter/x, youtube, linkedin, facebook, pinterest, threads. For video/image posts, pass a publicly reachable mediaUrl (e.g. a Google Drive webViewLink or Blob URL). Returns a per-platform result so partial success is visible.",
  inputSchema: z.object({
    platforms: z
      .array(z.string())
      .min(1)
      .describe(`Platform slugs to publish to. One or more of: ${SUPPORTED_PLATFORMS.join(", ")}.`),
    caption: z.string().min(1).describe("The post caption / text body."),
    mediaUrl: z
      .string()
      .url()
      .optional()
      .describe("Optional public URL of the image or video to attach."),
  }),
  // Publishing is an external, hard-to-reverse action. Ask the human to sign
  // off the first time in a session, then auto-allow the rest of the run.
  needsApproval: once(),
  async execute({ platforms, caption, mediaUrl }) {
    const results = await publishToSocial(platforms, caption, mediaUrl);
    const published = Object.entries(results)
      .filter(([, v]) => "success" in v)
      .map(([k]) => k);
    const failed = Object.entries(results)
      .filter(([, v]) => "error" in v)
      .map(([k]) => k);
    return { results, published, failed };
  },
  toModelOutput(output) {
    const parts = [];
    if (output.published.length) parts.push(`published to ${output.published.join(", ")}`);
    if (output.failed.length) parts.push(`failed on ${output.failed.join(", ")}`);
    return { type: "text", value: parts.join("; ") || "no platforms targeted" };
  },
});
