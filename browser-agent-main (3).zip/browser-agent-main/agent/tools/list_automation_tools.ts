import { defineTool } from "eve/tools";
import { z } from "zod";
import { isConfigured, listTools, type McpService } from "../../lib/mcp";

export default defineTool({
  description:
    "Discover the tools available on the automation MCP servers — Arcads (AI video ad generation) and n8n (workflow automation). Call this first to learn the exact tool names and argument schemas, then invoke one with call_automation_tool.",
  inputSchema: z.object({
    service: z
      .enum(["arcads", "n8n", "both"])
      .default("both")
      .describe("Which server(s) to introspect."),
  }),
  async execute({ service }) {
    const targets: McpService[] =
      service === "both" ? ["arcads", "n8n"] : [service];
    const out: Record<string, unknown> = {};
    for (const svc of targets) {
      if (!isConfigured(svc)) {
        out[svc] = { configured: false };
        continue;
      }
      try {
        out[svc] = { configured: true, tools: await listTools(svc) };
      } catch (err) {
        out[svc] = {
          configured: true,
          error: err instanceof Error ? err.message : String(err),
        };
      }
    }
    return out;
  },
});
