import { defineTool } from "eve/tools";
import { z } from "zod";
import { isDriveConfigured, uploadFromUrl } from "../../lib/drive";

export default defineTool({
  description:
    "Upload a file into the user's Google Drive by fetching it from a public URL. Use this to save a rendered Higgsfield/Arcads video or generated image straight into Drive — pass the asset's URL, a filename, and optionally a destination folder ID. Returns the created Drive file with its webViewLink.",
  inputSchema: z.object({
    url: z.string().url().describe("Public URL of the asset to upload."),
    name: z.string().min(1).describe("Filename to save it as in Drive."),
    folder: z
      .string()
      .optional()
      .describe("Destination Google Drive folder ID. Omit for the root folder."),
  }),
  async execute({ url, name, folder }) {
    if (!isDriveConfigured()) {
      return {
        configured: false,
        message:
          "Google Drive is not connected. Ask the user to visit /api/auth/google and set GOOGLE_REFRESH_TOKEN.",
      };
    }
    const file = await uploadFromUrl(url, name, folder ?? "root");
    return { configured: true, file };
  },
});
