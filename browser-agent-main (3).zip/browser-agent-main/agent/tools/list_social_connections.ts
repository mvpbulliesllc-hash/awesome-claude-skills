import { defineTool } from "eve/tools";
import { z } from "zod";
import { isComposioConfigured, listConnections } from "../../lib/composio";

export default defineTool({
  description:
    "List the social accounts currently connected through Composio (Instagram, TikTok, X/Twitter, YouTube, LinkedIn, Facebook, Pinterest, Threads). Use this before publishing to confirm which platforms are live.",
  inputSchema: z.object({}),
  async execute() {
    if (!isComposioConfigured()) {
      return { configured: false, message: "COMPOSIO_API_KEY is not set." };
    }
    try {
      return { configured: true, connections: await listConnections() };
    } catch (err) {
      return {
        configured: true,
        error: err instanceof Error ? err.message : String(err),
      };
    }
  },
});
