/**
 * Composio integration — social connector status + publishing.
 *
 * Shared by the `/api/composio` route and the agent's social tools so the
 * platform mappings and request shape live in exactly one place.
 *
 * Requires COMPOSIO_API_KEY in the environment.
 */

const COMPOSIO_BASE = "https://backend.composio.dev/api/v1";

/** Platform slug (lowercase) → Composio app name. */
export const PLATFORM_APP: Record<string, string> = {
  instagram: "INSTAGRAM",
  tiktok: "TIKTOK",
  twitter: "TWITTER",
  x: "TWITTER",
  youtube: "YOUTUBE",
  linkedin: "LINKEDIN",
  facebook: "FACEBOOK",
  pinterest: "PINTEREST",
  threads: "THREADS",
};

/** Composio app name → publish action. */
export const PLATFORM_ACTION: Record<string, string> = {
  INSTAGRAM: "INSTAGRAM_CREATE_PHOTO_POST",
  TIKTOK: "TIKTOK_UPLOAD_VIDEO",
  TWITTER: "TWITTER_CREATION_OF_A_POST",
  YOUTUBE: "YOUTUBE_UPLOAD_VIDEO",
  LINKEDIN: "LINKEDIN_CREATE_LINKED_IN_POST",
  FACEBOOK: "FACEBOOK_CREATE_POST",
  PINTEREST: "PINTEREST_CREATE_PIN",
  THREADS: "THREADS_CREATE_POST",
};

/** All platform slugs we can target. */
export const SUPPORTED_PLATFORMS = Object.keys(PLATFORM_APP);

export function isComposioConfigured(): boolean {
  return Boolean(process.env.COMPOSIO_API_KEY);
}

async function composioFetch(path: string, options: RequestInit = {}) {
  const apiKey = process.env.COMPOSIO_API_KEY;
  if (!apiKey) throw new Error("COMPOSIO_API_KEY not configured");

  const res = await fetch(`${COMPOSIO_BASE}${path}`, {
    ...options,
    headers: {
      "x-api-key": apiKey,
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Composio error ${res.status}: ${err}`);
  }

  return res.json();
}

/** List every connected account on the Composio project. */
export async function listConnections(): Promise<unknown> {
  return composioFetch("/connectedAccounts?limit=50");
}

export type PublishResult = Record<
  string,
  { success: true; data: unknown } | { error: string }
>;

/**
 * Publish a caption (and optional media URL) to one or more platforms.
 * Never throws for a single-platform failure — each platform's outcome is
 * captured independently so a partial publish still reports what landed.
 */
export async function publishToSocial(
  platforms: string[],
  caption: string,
  mediaUrl?: string,
): Promise<PublishResult> {
  const results: PublishResult = {};

  for (const platform of platforms) {
    const appName = PLATFORM_APP[platform.toLowerCase()];
    if (!appName) {
      results[platform] = { error: `Unknown platform: ${platform}` };
      continue;
    }
    const actionName = PLATFORM_ACTION[appName];
    if (!actionName) {
      results[platform] = { error: `No publish action for ${appName}` };
      continue;
    }

    try {
      const params: Record<string, unknown> = {
        caption,
        text: caption,
        content: caption,
      };
      if (mediaUrl) {
        params.imageUrl = mediaUrl;
        params.videoUrl = mediaUrl;
        params.mediaUrl = mediaUrl;
      }

      const data = await composioFetch("/actions/execute/handle", {
        method: "POST",
        body: JSON.stringify({ actionName, input: params }),
      });
      results[platform] = { success: true, data };
    } catch (err: unknown) {
      results[platform] = {
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  return results;
}

/** Run an arbitrary Composio action. */
export async function executeAction(
  appName: string | undefined,
  actionName: string,
  params: Record<string, unknown> = {},
): Promise<unknown> {
  return composioFetch("/actions/execute/handle", {
    method: "POST",
    body: JSON.stringify({ actionName, appName, input: params }),
  });
}
