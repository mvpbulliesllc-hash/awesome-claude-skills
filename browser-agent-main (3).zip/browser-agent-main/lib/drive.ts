/**
 * Google Drive integration — OAuth refresh-token flow + file operations.
 *
 * Shared by the `/api/drive` route and the agent's Drive tools.
 *
 * Requires GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REFRESH_TOKEN.
 */

const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
const DRIVE_API = "https://www.googleapis.com/drive/v3";
const UPLOAD_API = "https://www.googleapis.com/upload/drive/v3";

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  webViewLink?: string;
  thumbnailLink?: string;
}

export interface DriveListing {
  files: DriveFile[];
  nextPageToken?: string;
}

export function isDriveConfigured(): boolean {
  return Boolean(
    process.env.GOOGLE_CLIENT_ID &&
      process.env.GOOGLE_CLIENT_SECRET &&
      process.env.GOOGLE_REFRESH_TOKEN,
  );
}

/** Exchange the stored refresh token for a short-lived access token. */
export async function getAccessToken(): Promise<string> {
  const refreshToken = process.env.GOOGLE_REFRESH_TOKEN;
  if (!refreshToken) {
    throw new Error(
      "GOOGLE_REFRESH_TOKEN not set. Visit /api/auth/google to connect Google Drive.",
    );
  }

  const res = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID ?? "",
      client_secret: process.env.GOOGLE_CLIENT_SECRET ?? "",
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });

  if (!res.ok) {
    throw new Error(`Google token refresh failed: ${await res.text()}`);
  }

  const data = (await res.json()) as { access_token: string };
  return data.access_token;
}

/** List non-trashed files in a folder ("root" by default). */
export async function listFiles(
  folder = "root",
  pageToken?: string,
): Promise<DriveListing> {
  const token = await getAccessToken();

  const params = new URLSearchParams({
    q: `'${folder}' in parents and trashed = false`,
    fields:
      "nextPageToken,files(id,name,mimeType,size,modifiedTime,webViewLink,thumbnailLink)",
    orderBy: "folder,modifiedTime desc",
    pageSize: "100",
  });
  if (pageToken) params.set("pageToken", pageToken);

  const res = await fetch(`${DRIVE_API}/files?${params}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(await res.text());

  return (await res.json()) as DriveListing;
}

/** Upload raw bytes to a folder via a resumable upload. */
export async function uploadFile(
  name: string,
  bytes: ArrayBuffer,
  contentType: string,
  folder = "root",
): Promise<DriveFile> {
  const token = await getAccessToken();

  const initRes = await fetch(`${UPLOAD_API}/files?uploadType=resumable`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json; charset=UTF-8",
      "X-Upload-Content-Type": contentType || "application/octet-stream",
      "X-Upload-Content-Length": String(bytes.byteLength),
    },
    body: JSON.stringify({ name, parents: [folder] }),
  });
  if (!initRes.ok) throw new Error(await initRes.text());

  const uploadUrl = initRes.headers.get("location");
  if (!uploadUrl) throw new Error("Drive did not return a resumable upload URL");

  const uploadRes = await fetch(uploadUrl, {
    method: "PUT",
    headers: {
      "Content-Type": contentType || "application/octet-stream",
      "Content-Length": String(bytes.byteLength),
    },
    body: bytes,
  });
  if (!uploadRes.ok) throw new Error(await uploadRes.text());

  return (await uploadRes.json()) as DriveFile;
}

/** Fetch a public/accessible URL and upload its bytes into Drive. */
export async function uploadFromUrl(
  url: string,
  name: string,
  folder = "root",
): Promise<DriveFile> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch source URL: ${res.status}`);
  const contentType =
    res.headers.get("content-type") ?? "application/octet-stream";
  const bytes = await res.arrayBuffer();
  return uploadFile(name, bytes, contentType, folder);
}

export interface DriveStorage {
  limit?: string;
  usage?: string;
  usageInDrive?: string;
}

/** Fetch the account's storage quota + usage. */
export async function getStorage(): Promise<DriveStorage> {
  const token = await getAccessToken();
  const res = await fetch(`${DRIVE_API}/about?fields=storageQuota`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(await res.text());
  const data = (await res.json()) as { storageQuota?: DriveStorage };
  return data.storageQuota ?? {};
}

/** Move a file to the trash. */
export async function trashFile(fileId: string): Promise<void> {
  const token = await getAccessToken();
  const res = await fetch(`${DRIVE_API}/files/${fileId}/trash`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(await res.text());
}

/** Get a temporary authenticated download URL + token for a file's bytes. */
export function downloadUrl(fileId: string): string {
  return `${DRIVE_API}/files/${fileId}?alt=media`;
}

/** Stream a file's bytes (uses a fresh access token). */
export async function downloadFile(fileId: string): Promise<Response> {
  const token = await getAccessToken();
  return fetch(downloadUrl(fileId), {
    headers: { Authorization: `Bearer ${token}` },
  });
}
