/**
 * MCP (JSON-RPC over HTTP) client for the Arcads and n8n servers.
 *
 * Shared by the `/api/arcads` route and the agent's automation tools.
 *
 * Requires ARCADS_MCP_URL and/or N8N_MCP_URL. An optional bearer key can be
 * supplied per-service via ARCADS_MCP_KEY / N8N_MCP_KEY.
 */

export type McpService = "arcads" | "n8n";

let rpcId = 0;

function serviceUrl(service: McpService): string {
  const url =
    service === "arcads"
      ? process.env.ARCADS_MCP_URL
      : process.env.N8N_MCP_URL;
  if (!url) {
    throw new Error(
      `${service === "arcads" ? "ARCADS_MCP_URL" : "N8N_MCP_URL"} not configured`,
    );
  }
  return url;
}

function serviceKey(service: McpService): string | undefined {
  return service === "arcads"
    ? process.env.ARCADS_MCP_KEY
    : process.env.N8N_MCP_KEY;
}

export function isConfigured(service: McpService): boolean {
  return Boolean(
    service === "arcads" ? process.env.ARCADS_MCP_URL : process.env.N8N_MCP_URL,
  );
}

/** Low-level JSON-RPC call against a service's MCP endpoint. */
export async function mcpCall(
  service: McpService,
  method: string,
  params: Record<string, unknown> = {},
): Promise<unknown> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json, text/event-stream",
  };
  const key = serviceKey(service);
  if (key) {
    headers.Authorization = `Bearer ${key}`;
    headers["x-api-key"] = key;
  }

  // rpcId is a monotonic per-process counter — no Date.now() needed and it
  // stays unique across concurrent calls within a request.
  const id = ++rpcId;

  const res = await fetch(serviceUrl(service), {
    method: "POST",
    headers,
    body: JSON.stringify({ jsonrpc: "2.0", id, method, params }),
  });

  if (!res.ok) {
    throw new Error(`MCP ${service} error ${res.status}: ${await res.text()}`);
  }

  return res.json();
}

/** List the tools a service exposes. */
export async function listTools(service: McpService): Promise<unknown> {
  return mcpCall(service, "tools/list", {});
}

/** Invoke a named tool on a service. */
export async function callTool(
  service: McpService,
  name: string,
  args: Record<string, unknown> = {},
): Promise<unknown> {
  return mcpCall(service, "tools/call", { name, arguments: args });
}
