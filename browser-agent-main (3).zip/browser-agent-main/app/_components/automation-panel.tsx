"use client";

import {
  ChevronRightIcon,
  EllipsisIcon,
  PlusIcon,
  ZapIcon,
} from "lucide-react";
import { useEffect, useState } from "react";

const CONNECTED_TOOLS = [
  { name: "Google Drive", dot: "#4285F4", match: "drive", kind: "google" },
  { name: "Instagram", dot: "#E1306C", match: "instagram", kind: "composio" },
  { name: "TikTok", dot: "#69C9D0", match: "tiktok", kind: "composio" },
  { name: "YouTube", dot: "#FF0000", match: "youtube", kind: "composio" },
  { name: "X / Twitter", dot: "#1DA1F2", match: "twitter", kind: "composio" },
  { name: "LinkedIn", dot: "#0077B5", match: "linkedin", kind: "composio" },
  { name: "Composio", dot: "#6366f1", match: "", kind: "composio-core" },
  { name: "Arcads", dot: "#7c3aed", match: "", kind: "arcads" },
  { name: "n8n", dot: "#EA4B71", match: "", kind: "n8n" },
] as const;

type ToolState = "connected" | "off" | "unknown";

const TEMPLATES = [
  { label: "Content → Drive", desc: "Generate content and sync to Drive automatically" },
  { label: "Drive → All Social", desc: "New Drive file triggers cross-platform publish" },
  { label: "Brief → Video", desc: "Convert text brief to Higgsfield video" },
];

const AUTOMATIONS = [
  { name: "Content generation pipeline", trigger: "New brief uploaded", lastRun: "2 min ago", status: "Active" },
  { name: "Social distribution flow", trigger: "New Drive asset", lastRun: "15 min ago", status: "Active" },
  { name: "Video render → upload", trigger: "Render complete", lastRun: "30 min ago", status: "Active" },
  { name: "Onboarding checklist", trigger: "New user added", lastRun: "1 hour ago", status: "Active" },
  { name: "Analytics digest", trigger: "Daily schedule", lastRun: "2 hours ago", status: "Active" },
];

const RECENT_RUNS = [
  { name: "Content pipeline", time: "2 min ago", status: "Success" },
  { name: "Social distribution", time: "15 min ago", status: "Success" },
  { name: "Video render upload", time: "30 min ago", status: "Success" },
  { name: "Onboarding checklist", time: "1 hour ago", status: "Success" },
  { name: "Analytics digest", time: "2 hours ago", status: "Success" },
];

export function AutomationPanel() {
  const [state, setState] = useState<Record<string, ToolState>>({});

  useEffect(() => {
    (async () => {
      const next: Record<string, ToolState> = {};
      // Composio: which social accounts are linked + is the API reachable.
      try {
        const res = await fetch("/api/composio");
        const data = await res.json();
        const reachable = res.ok;
        const blob = JSON.stringify(data.connections ?? data).toLowerCase();
        for (const t of CONNECTED_TOOLS) {
          if (t.kind === "composio") next[t.name] = blob.includes(t.match) ? "connected" : "off";
          else if (t.kind === "composio-core") next[t.name] = reachable ? "connected" : "off";
        }
      } catch {
        for (const t of CONNECTED_TOOLS) if (t.kind.startsWith("composio")) next[t.name] = "unknown";
      }
      // Drive
      try {
        const res = await fetch("/api/drive?about=1");
        next["Google Drive"] = res.ok ? "connected" : "off";
      } catch {
        next["Google Drive"] = "unknown";
      }
      // Arcads + n8n MCP servers
      try {
        const res = await fetch("/api/arcads");
        const data = await res.json();
        const svc = data.services ?? {};
        next["Arcads"] = svc.arcads?.configured && !svc.arcads?.error ? "connected" : "off";
        next["n8n"] = svc.n8n?.configured && !svc.n8n?.error ? "connected" : "off";
      } catch {
        next["Arcads"] = "unknown";
        next["n8n"] = "unknown";
      }
      setState(next);
    })();
  }, []);

  const statusOf = (name: string): ToolState => state[name] ?? "unknown";

  return (
    <div className="flex h-full overflow-hidden">
      {/* Main */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <ZapIcon className="size-3" />
              Automation
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Connect agents to the tools your business runs on</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
            Integrate with your existing stack and let agents automate workflows, update systems, trigger actions, and coordinate processes across teams.
          </p>
          <div className="flex items-center gap-2 mt-4">
            <button className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium bg-white text-black hover:bg-white/90 transition-colors">
              <PlusIcon className="size-3.5" />
              New automation
            </button>
            <button className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm border hover:bg-white/5 transition-colors" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              Browse templates
            </button>
          </div>
        </div>

        {/* Templates */}
        <div>
          <h3 className="text-sm font-medium mb-3">Popular templates</h3>
          <div className="grid grid-cols-3 gap-3">
            {TEMPLATES.map((tpl) => (
              <button
                key={tpl.label}
                className="rounded-lg border p-3 text-left hover:bg-white/3 transition-colors group"
                style={{ borderColor: "var(--border)", background: "var(--card)" }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <ZapIcon className="size-4 text-[color:var(--warning)]" />
                  <span className="text-xs font-medium">{tpl.label}</span>
                </div>
                <p className="text-[11px] leading-relaxed" style={{ color: "var(--muted-foreground)" }}>{tpl.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Automations table */}
        <div>
          <h3 className="text-sm font-medium mb-3">Your automations</h3>
          <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
            <div className="grid grid-cols-[2fr_1.5fr_1fr_1fr_auto] px-4 py-2.5 text-xs border-b" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <span>Automation</span>
              <span>Trigger</span>
              <span>Last run</span>
              <span>Status</span>
              <span />
            </div>
            {AUTOMATIONS.map((auto, i) => (
              <div
                key={auto.name}
                className={`grid grid-cols-[2fr_1.5fr_1fr_1fr_auto] items-center px-4 py-2.5 hover:bg-white/3 transition-colors ${i < AUTOMATIONS.length - 1 ? "border-b" : ""}`}
                style={{ borderColor: "var(--border)" }}
              >
                <span className="text-sm">{auto.name}</span>
                <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{auto.trigger}</span>
                <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{auto.lastRun}</span>
                <div className="flex items-center gap-1.5">
                  <span className="size-1.5 rounded-full bg-[color:var(--success)]" />
                  <span className="text-xs text-[color:var(--success)]">{auto.status}</span>
                </div>
                <button className="p-1 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
                  <EllipsisIcon className="size-3.5" />
                </button>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center py-3">
            <button className="flex items-center gap-1 text-sm hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
              View all automations <ChevronRightIcon className="size-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Right panel */}
      <aside className="w-64 shrink-0 border-l overflow-y-auto p-4 space-y-5" style={{ borderColor: "var(--border)", background: "var(--panel)" }}>
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold">Connected tools</span>
            <button className="text-[10px] hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>Manage</button>
          </div>
          <div className="space-y-2">
            {CONNECTED_TOOLS.map((tool) => {
              const s = statusOf(tool.name);
              const label = s === "connected" ? "Connected" : s === "off" ? "Off" : "…";
              const dotClass =
                s === "connected"
                  ? "bg-[color:var(--success)]"
                  : s === "off"
                    ? "bg-white/20"
                    : "bg-white/40 animate-pulse";
              const textClass =
                s === "connected" ? "text-[color:var(--success)]" : "text-[color:var(--muted-foreground)]";
              return (
                <div key={tool.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="size-4 rounded" style={{ background: tool.dot }} />
                    <span className="text-xs">{tool.name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className={`size-1.5 rounded-full ${dotClass}`} />
                    <span className={`text-[10px] ${textClass}`}>{label}</span>
                  </div>
                </div>
              );
            })}
            <button className="flex items-center gap-1.5 mt-1 text-xs hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
              <PlusIcon className="size-3" />
              Add connection
            </button>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold">Recent runs</span>
            <button className="text-[10px] hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>View all</button>
          </div>
          <div className="space-y-2">
            {RECENT_RUNS.map((run, i) => (
              <div key={i} className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium">{run.name}</div>
                  <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{run.time}</div>
                </div>
                <span className="text-[10px] text-[color:var(--success)]">{run.status}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-3">Automation impact</div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Workflows", value: "1,248", delta: "+24%" },
              { label: "Tasks auto", value: "3,612", delta: "+18%" },
              { label: "Time saved", value: "126h", delta: "+32%" },
            ].map((stat) => (
              <div key={stat.label} className="rounded-md p-2 text-center" style={{ background: "var(--secondary)" }}>
                <div className="text-sm font-semibold">{stat.value}</div>
                <div className="text-[9px] text-[color:var(--success)]">{stat.delta}</div>
                <div className="text-[9px] mt-0.5" style={{ color: "var(--muted-foreground)" }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
