"use client";

import {
  CloudUploadIcon,
  DownloadIcon,
  FilmIcon,
  FolderOpenIcon,
  ImageIcon,
  PlusIcon,
  RefreshCwIcon,
  SparklesIcon,
  UploadIcon,
  VideoIcon,
  WandIcon,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";

const PLATFORMS = ["Higgsfield AI", "Arcads", "Google Drive", "All Platforms"];

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  webViewLink?: string;
}

function formatBytes(bytes?: string): string {
  const n = Number(bytes);
  if (!n || Number.isNaN(n)) return "";
  const units = ["B", "KB", "MB", "GB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function relativeTime(iso?: string): string {
  if (!iso) return "";
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export function ContentStudio({ onSendToBrain }: { onSendToBrain?: (text: string) => void }) {
  const [activeTab, setActiveTab] = useState<"create" | "drive">("create");
  const [selectedPlatform, setSelectedPlatform] = useState("Higgsfield AI");
  const [brief, setBrief] = useState("");
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [driveConfigured, setDriveConfigured] = useState(true);
  const [autoStatus, setAutoStatus] = useState<string>("Checking automation servers…");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const briefInputRef = useRef<HTMLInputElement>(null);

  const loadFiles = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/drive");
      const data = await res.json();
      if (res.ok) {
        setDriveConfigured(true);
        setFiles(data.files ?? []);
      } else {
        setDriveConfigured(false);
        setFiles([]);
      }
    } catch {
      setDriveConfigured(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadFiles();
  }, [loadFiles]);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/arcads");
        const data = await res.json();
        const svc = data.services ?? {};
        const live = ["arcads", "n8n"].filter((s) => svc[s]?.configured && !svc[s]?.error);
        setAutoStatus(
          live.length ? `${live.join(" + ")} connected` : "Arcads / n8n not configured",
        );
      } catch {
        setAutoStatus("Automation servers unreachable");
      }
    })();
  }, []);

  const generate = () => {
    const notes = brief.trim();
    onSendToBrain?.(
      `Create a video via ${selectedPlatform}.${notes ? ` Brief: ${notes}` : ""} ` +
        `Use the automation tools (list_automation_tools, then call_automation_tool for Arcads) or the cloud browser for Higgsfield, then upload the result to Google Drive.`,
    );
  };

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/drive", { method: "POST", body: form });
      if (res.ok) await loadFiles();
    } finally {
      setUploading(false);
    }
  };

  const download = (file: DriveFile) => {
    window.open(
      `/api/drive?download=${encodeURIComponent(file.id)}&name=${encodeURIComponent(file.name)}`,
      "_blank",
    );
  };

  const media = files.filter(
    (f) => f.mimeType.startsWith("video/") || f.mimeType.startsWith("image/"),
  );

  return (
    <div className="flex h-full overflow-hidden">
      {/* Main */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <VideoIcon className="size-3" />
              Content Studio
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Create, render, and distribute content</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
            Generate videos via Higgsfield AI &amp; Arcads, sync assets through Google Drive, and distribute everywhere via Composio.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 p-1 rounded-lg w-fit" style={{ background: "var(--secondary)" }}>
          {(["create", "drive"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors capitalize ${activeTab === tab ? "bg-white text-black" : "text-[color:var(--muted-foreground)] hover:text-white"}`}
            >
              {tab === "create" ? "Create Content" : "Google Drive"}
            </button>
          ))}
        </div>

        {activeTab === "create" ? (
          <div className="space-y-5">
            {/* Platform selector */}
            <div className="flex items-center gap-2">
              {PLATFORMS.map((p) => (
                <button
                  key={p}
                  onClick={() => setSelectedPlatform(p)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors border ${selectedPlatform === p ? "bg-violet-500/20 border-violet-500/40 text-violet-300" : "border-[color:var(--border)] text-[color:var(--muted-foreground)] hover:text-white hover:border-white/20"}`}
                >
                  {p}
                </button>
              ))}
            </div>

            {/* Creation card */}
            <div className="rounded-xl border p-6" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <h3 className="text-base font-semibold mb-1">New Content Job</h3>
                  <p className="text-xs mb-4" style={{ color: "var(--muted-foreground)" }}>
                    Describe your video concept and Claude Brain will generate, render, and upload it to your Google Drive.
                  </p>
                  <textarea
                    value={brief}
                    onChange={(e) => setBrief(e.target.value)}
                    placeholder="Describe your video: target platform, tone, key message, duration, visual style..."
                    className="w-full rounded-lg border px-3 py-2.5 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-white/20 bg-transparent leading-relaxed"
                    style={{ borderColor: "var(--border)", minHeight: 100 }}
                  />
                  <div className="flex items-center gap-2 mt-3">
                    <button
                      onClick={generate}
                      className="flex items-center gap-1.5 rounded-md px-4 py-2 text-sm font-medium bg-violet-600 text-white hover:bg-violet-500 transition-colors"
                    >
                      <WandIcon className="size-3.5" />
                      Generate with AI
                    </button>
                    <input
                      ref={briefInputRef}
                      type="file"
                      className="hidden"
                      onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
                    />
                    <button
                      onClick={() => briefInputRef.current?.click()}
                      disabled={uploading || !driveConfigured}
                      className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm border hover:bg-white/5 transition-colors disabled:opacity-50"
                      style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}
                    >
                      {uploading ? <RefreshCwIcon className="size-3.5 animate-spin" /> : <UploadIcon className="size-3.5" />}
                      Upload brief
                    </button>
                  </div>
                </div>
                <div className="w-40 h-32 rounded-lg border flex flex-col items-center justify-center gap-2 shrink-0" style={{ borderColor: "var(--border)", background: "var(--secondary)" }}>
                  <FilmIcon className="size-8" style={{ color: "var(--muted-foreground)" }} />
                  <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>Preview</span>
                </div>
              </div>
            </div>

            {/* Recent media from Drive */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium">Recent rendered content</h3>
                <button onClick={loadFiles} className="flex items-center gap-1 text-xs hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
                  <RefreshCwIcon className={`size-3 ${loading ? "animate-spin" : ""}`} /> Refresh
                </button>
              </div>
              {media.length === 0 ? (
                <div className="rounded-lg border p-6 text-center text-sm" style={{ borderColor: "var(--border)", background: "var(--card)", color: "var(--muted-foreground)" }}>
                  {driveConfigured ? "No rendered videos or images in Drive yet." : "Connect Google Drive to see rendered content."}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  {media.slice(0, 6).map((file) => (
                    <div key={file.id} className="rounded-lg border p-3 hover:bg-white/3 transition-colors" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
                      <div className="h-20 rounded-md mb-3 flex items-center justify-center bg-violet-500/20">
                        {file.mimeType.startsWith("video/") ? (
                          <FilmIcon className="size-8 text-violet-400" />
                        ) : (
                          <ImageIcon className="size-8 text-emerald-400" />
                        )}
                      </div>
                      <div className="text-sm font-medium truncate">{file.name}</div>
                      <div className="flex items-center justify-between mt-1.5">
                        <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{formatBytes(file.size)}</span>
                        <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{relativeTime(file.modifiedTime)}</span>
                        <button onClick={() => download(file)} className="flex items-center gap-1 text-[10px] hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
                          <DownloadIcon className="size-3" /> Get
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Upload zone */}
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading || !driveConfigured}
              className="w-full rounded-xl border-2 border-dashed p-10 text-center hover:border-white/20 transition-colors cursor-pointer disabled:opacity-50"
              style={{ borderColor: "var(--border)", background: "var(--card)" }}
            >
              <CloudUploadIcon className="size-10 mx-auto mb-3" style={{ color: "var(--muted-foreground)" }} />
              <div className="text-sm font-medium mb-1">{uploading ? "Uploading…" : "Upload to Google Drive"}</div>
              <div className="text-xs" style={{ color: "var(--muted-foreground)" }}>
                {driveConfigured ? "Click to browse and upload a file" : "Connect Google Drive to upload"}
              </div>
            </button>

            {/* Drive files */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium">Drive files</h3>
                <button onClick={loadFiles} className="flex items-center gap-1 text-xs hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
                  <RefreshCwIcon className={`size-3 ${loading ? "animate-spin" : ""}`} /> Refresh
                </button>
              </div>
              <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
                {files.filter((f) => f.mimeType !== "application/vnd.google-apps.folder").length === 0 ? (
                  <div className="px-4 py-8 text-center text-sm" style={{ color: "var(--muted-foreground)" }}>
                    {driveConfigured ? "No files yet." : "Connect Google Drive to browse files."}
                  </div>
                ) : (
                  files
                    .filter((f) => f.mimeType !== "application/vnd.google-apps.folder")
                    .map((file, i, arr) => (
                      <div
                        key={file.id}
                        className={`flex items-center justify-between px-4 py-3 hover:bg-white/3 transition-colors ${i < arr.length - 1 ? "border-b" : ""}`}
                        style={{ borderColor: "var(--border)" }}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="size-8 rounded-md bg-[#4285F4]/20 flex items-center justify-center shrink-0">
                            <FolderOpenIcon className="size-4 text-[#4285F4]" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-medium truncate">{file.name}</div>
                            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>
                              {formatBytes(file.size)} · {relativeTime(file.modifiedTime)}
                            </div>
                          </div>
                        </div>
                        <button onClick={() => download(file)} className="p-1.5 rounded hover:bg-white/10 transition-colors shrink-0" style={{ color: "var(--muted-foreground)" }}>
                          <DownloadIcon className="size-3.5" />
                        </button>
                      </div>
                    ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right panel */}
      <aside className="w-64 shrink-0 border-l overflow-y-auto p-4 space-y-5" style={{ borderColor: "var(--border)", background: "var(--panel)" }}>
        <div>
          <div className="text-xs font-semibold mb-3">Content pipeline</div>
          <div className="space-y-3">
            {[
              { step: "01", label: "Write brief", desc: "Define goals, platform, tone" },
              { step: "02", label: "AI generation", desc: "Higgsfield / Arcads renders" },
              { step: "03", label: "Drive sync", desc: "Auto-upload to Google Drive" },
              { step: "04", label: "Distribute", desc: "Composio pushes to all socials" },
            ].map((item) => (
              <div key={item.step} className="flex items-start gap-3">
                <div className="size-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 bg-white/10 text-[color:var(--muted-foreground)]">
                  {item.step}
                </div>
                <div>
                  <div className="text-xs font-medium">{item.label}</div>
                  <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{item.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-2">Automation status</div>
          <div className="rounded-md p-3 border" style={{ borderColor: "var(--border)", background: "var(--secondary)" }}>
            <div className="flex items-center gap-1.5">
              <span className={`size-1.5 rounded-full ${/connected/.test(autoStatus) ? "bg-[color:var(--success)]" : "bg-[color:var(--warning)]"}`} />
              <span className="text-[11px]">{autoStatus}</span>
            </div>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-3">Quick actions</div>
          <div className="space-y-2">
            {[
              { label: "New video brief", icon: <PlusIcon className="size-3.5" />, action: () => setActiveTab("create") },
              { label: "Generate with Claude", icon: <SparklesIcon className="size-3.5" />, action: generate },
              { label: "Open Drive files", icon: <FolderOpenIcon className="size-3.5" />, action: () => setActiveTab("drive") },
            ].map((action) => (
              <button
                key={action.label}
                onClick={action.action}
                className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-xs border hover:bg-white/5 transition-colors"
                style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}
              >
                {action.icon}
                {action.label}
              </button>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
