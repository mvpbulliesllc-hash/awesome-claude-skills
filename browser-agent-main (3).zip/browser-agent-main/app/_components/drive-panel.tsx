"use client";

import {
  ChevronRightIcon,
  CloudUploadIcon,
  DownloadIcon,
  FileTextIcon,
  FilmIcon,
  FolderIcon,
  FolderOpenIcon,
  ImageIcon,
  RefreshCwIcon,
  SearchIcon,
  Trash2Icon,
  TriangleAlertIcon,
  UploadIcon,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";

const FOLDER_MIME = "application/vnd.google-apps.folder";

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  webViewLink?: string;
}

interface Storage {
  limit?: string;
  usage?: string;
}

function formatBytes(bytes?: string | number): string {
  const n = typeof bytes === "string" ? Number(bytes) : bytes;
  if (!n || Number.isNaN(n)) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function relativeTime(iso?: string): string {
  if (!iso) return "";
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

function fileIcon(mimeType: string) {
  if (mimeType === FOLDER_MIME) return <FolderOpenIcon className="size-4 text-[#4285F4]" />;
  if (mimeType.startsWith("video/")) return <FilmIcon className="size-4 text-violet-400" />;
  if (mimeType.startsWith("image/")) return <ImageIcon className="size-4 text-emerald-400" />;
  return <FileTextIcon className="size-4 text-blue-400" />;
}

interface Crumb {
  id: string;
  name: string;
}

export function DrivePanel() {
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [storage, setStorage] = useState<Storage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notConfigured, setNotConfigured] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState("");
  const [trail, setTrail] = useState<Crumb[]>([{ id: "root", name: "My Drive" }]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentFolder = trail[trail.length - 1].id;

  const load = useCallback(async (folder: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/drive?folder=${encodeURIComponent(folder)}`);
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 400 || /not set|not configured/i.test(data.error ?? "")) {
          setNotConfigured(true);
        }
        setError(data.error ?? "Failed to load Drive");
        setFiles([]);
        return;
      }
      setNotConfigured(false);
      setFiles(data.files ?? []);
    } catch {
      setError("Network error reaching Google Drive");
      setFiles([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadStorage = useCallback(async () => {
    try {
      const res = await fetch("/api/drive?about=1");
      const data = await res.json();
      if (res.ok) setStorage(data.storage ?? null);
    } catch {
      /* non-fatal */
    }
  }, []);

  useEffect(() => {
    load(currentFolder);
  }, [currentFolder, load]);

  useEffect(() => {
    loadStorage();
  }, [loadStorage]);

  const openFolder = (f: DriveFile) => setTrail((t) => [...t, { id: f.id, name: f.name }]);
  const goToCrumb = (i: number) => setTrail((t) => t.slice(0, i + 1));

  const handleFilePicked = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = e.target.files?.[0];
    if (!picked) return;
    setUploading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", picked);
      form.append("folder", currentFolder);
      const res = await fetch("/api/drive", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) setError(data.error ?? "Upload failed");
      else {
        await load(currentFolder);
        loadStorage();
      }
    } catch {
      setError("Upload network error");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDelete = async (file: DriveFile) => {
    setError(null);
    try {
      const res = await fetch(`/api/drive?id=${encodeURIComponent(file.id)}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error ?? "Delete failed");
      } else {
        setFiles((prev) => prev.filter((f) => f.id !== file.id));
        loadStorage();
      }
    } catch {
      setError("Delete network error");
    }
  };

  const download = (file: DriveFile) => {
    const url = `/api/drive?download=${encodeURIComponent(file.id)}&name=${encodeURIComponent(file.name)}`;
    window.open(url, "_blank");
  };

  const folders = files.filter((f) => f.mimeType === FOLDER_MIME);
  const docs = files.filter((f) => f.mimeType !== FOLDER_MIME);
  const filteredDocs = docs.filter((f) =>
    f.name.toLowerCase().includes(search.toLowerCase()),
  );

  const usedPct =
    storage?.limit && storage?.usage
      ? Math.min(100, Math.round((Number(storage.usage) / Number(storage.limit)) * 100))
      : null;

  return (
    <div className="flex h-full overflow-hidden">
      {/* Main */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <FolderIcon className="size-3" />
              Google Drive
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Google Drive sync agent</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
            Upload content directly from Higgsfield &amp; Arcads into your Drive, or download assets straight to your workflow.
          </p>

          {/* Breadcrumb */}
          <div className="flex items-center gap-1 mt-3 text-xs" style={{ color: "var(--muted-foreground)" }}>
            {trail.map((c, i) => (
              <span key={c.id} className="flex items-center gap-1">
                {i > 0 && <ChevronRightIcon className="size-3" />}
                <button
                  onClick={() => goToCrumb(i)}
                  className={i === trail.length - 1 ? "text-white" : "hover:text-white transition-colors"}
                >
                  {c.name}
                </button>
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 mt-4">
            <input ref={fileInputRef} type="file" className="hidden" onChange={handleFilePicked} />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading || notConfigured}
              className="flex items-center gap-1.5 rounded-md px-4 py-2 text-sm font-medium bg-[#4285F4] text-white hover:bg-[#3367d6] transition-colors disabled:opacity-60"
            >
              {uploading ? <RefreshCwIcon className="size-3.5 animate-spin" /> : <UploadIcon className="size-3.5" />}
              {uploading ? "Uploading..." : "Upload to Drive"}
            </button>
            <button
              onClick={() => load(currentFolder)}
              className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm border hover:bg-white/5 transition-colors"
              style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}
            >
              <RefreshCwIcon className={`size-3.5 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </button>
          </div>
        </div>

        {notConfigured && (
          <div className="flex items-start gap-3 rounded-lg border px-4 py-3 text-sm" style={{ borderColor: "var(--warning)", background: "color-mix(in srgb, var(--warning) 8%, transparent)" }}>
            <TriangleAlertIcon className="size-4 shrink-0 mt-0.5 text-[color:var(--warning)]" />
            <div>
              <div className="font-medium">Google Drive not connected</div>
              <div className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>
                Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET and GOOGLE_REFRESH_TOKEN, or visit{" "}
                <a href="/api/auth/google" className="underline">/api/auth/google</a> to connect.
              </div>
            </div>
          </div>
        )}

        {error && !notConfigured && (
          <div className="flex items-start gap-3 rounded-lg border px-4 py-2.5 text-sm" style={{ borderColor: "var(--destructive)", background: "color-mix(in srgb, var(--destructive) 6%, transparent)" }}>
            <TriangleAlertIcon className="size-4 shrink-0 mt-0.5 text-[color:var(--destructive)]" />
            <span style={{ color: "var(--muted-foreground)" }}>{error}</span>
          </div>
        )}

        {/* Folders */}
        {folders.length > 0 && (
          <div>
            <h3 className="text-sm font-medium mb-3">Folders</h3>
            <div className="grid grid-cols-3 gap-3">
              {folders.map((folder) => (
                <button
                  key={folder.id}
                  onClick={() => openFolder(folder)}
                  className="rounded-lg border p-4 text-left hover:bg-white/3 transition-colors"
                  style={{ borderColor: "var(--border)", background: "var(--card)" }}
                >
                  <FolderOpenIcon className="size-6 mb-2 text-[#4285F4]" />
                  <div className="text-sm font-medium truncate">{folder.name}</div>
                  <div className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>
                    {relativeTime(folder.modifiedTime) || "folder"}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Files */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium">Files</h3>
            <div className="relative">
              <SearchIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3" style={{ color: "var(--muted-foreground)" }} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search files..."
                className="rounded-md pl-7 pr-3 py-1 text-xs border focus:outline-none focus:ring-1 focus:ring-white/20 bg-transparent w-40"
                style={{ borderColor: "var(--border)" }}
              />
            </div>
          </div>
          <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
            <div className="grid grid-cols-[2fr_1fr_1fr_auto] px-4 py-2.5 text-xs border-b" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <span>Name</span>
              <span>Size</span>
              <span>Modified</span>
              <span />
            </div>

            {loading ? (
              <div className="px-4 py-10 text-center text-sm" style={{ color: "var(--muted-foreground)" }}>
                <RefreshCwIcon className="size-5 mx-auto mb-2 animate-spin" />
                Loading Drive…
              </div>
            ) : filteredDocs.length === 0 ? (
              <div className="px-4 py-10 text-center text-sm" style={{ color: "var(--muted-foreground)" }}>
                {notConfigured ? "Connect Drive to see your files." : "No files here yet."}
              </div>
            ) : (
              filteredDocs.map((file, i) => (
                <div
                  key={file.id}
                  className={`grid grid-cols-[2fr_1fr_1fr_auto] items-center px-4 py-2.5 hover:bg-white/3 transition-colors ${i < filteredDocs.length - 1 ? "border-b" : ""}`}
                  style={{ borderColor: "var(--border)" }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {fileIcon(file.mimeType)}
                    <span className="text-sm truncate">{file.name}</span>
                  </div>
                  <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{formatBytes(file.size)}</span>
                  <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{relativeTime(file.modifiedTime)}</span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => download(file)} title="Download" className="p-1 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
                      <DownloadIcon className="size-3.5" />
                    </button>
                    <button onClick={() => handleDelete(file)} title="Move to trash" className="p-1 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
                      <Trash2Icon className="size-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <aside className="w-64 shrink-0 border-l overflow-y-auto p-4 space-y-5" style={{ borderColor: "var(--border)", background: "var(--panel)" }}>
        <div>
          <div className="text-xs font-semibold mb-3">Storage overview</div>
          {usedPct !== null ? (
            <div className="space-y-2">
              <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                <div className="h-full rounded-full bg-[#4285F4]" style={{ width: `${usedPct}%` }} />
              </div>
              <div className="flex justify-between text-[10px]" style={{ color: "var(--muted-foreground)" }}>
                <span>{formatBytes(storage?.usage)} used</span>
                <span>{formatBytes(storage?.limit)} total</span>
              </div>
            </div>
          ) : (
            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>
              {notConfigured ? "Connect Drive to see storage." : "—"}
            </div>
          )}
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-3">Recent in this folder</div>
          <div className="space-y-2.5">
            {docs.slice(0, 5).map((file) => (
              <div key={file.id} className="flex items-start gap-2">
                <CloudUploadIcon className="size-3.5 shrink-0 mt-0.5 text-[#4285F4]" />
                <div className="min-w-0">
                  <div className="text-[10px] leading-snug truncate">{file.name}</div>
                  <div className="text-[9px]" style={{ color: "var(--muted-foreground)" }}>{relativeTime(file.modifiedTime)}</div>
                </div>
              </div>
            ))}
            {docs.length === 0 && (
              <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>No recent files.</div>
            )}
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-2">Agent access</div>
          <div className="rounded-md p-3 border" style={{ borderColor: "var(--border)", background: "var(--secondary)" }}>
            <div className="flex items-center gap-1.5 mb-1">
              <span className={`size-1.5 rounded-full ${notConfigured ? "bg-[color:var(--warning)]" : "bg-[color:var(--success)]"}`} />
              <span className="text-xs">{notConfigured ? "Drive not connected" : "Drive Sync Agent active"}</span>
            </div>
            <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>
              Claude Brain can list, upload, download, and organize these files via its Drive tools.
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
