"use client";

import {
  ArrowLeftIcon,
  ArrowRightIcon,
  Maximize2Icon,
  Minimize2Icon,
  MonitorIcon,
  RefreshCwIcon,
  XIcon,
} from "lucide-react";
import { useState } from "react";

interface CloudBrowserViewProps {
  liveUrl?: string | null;
}

export function CloudBrowserView({ liveUrl }: CloudBrowserViewProps) {
  const [urlInput, setUrlInput] = useState("https://higgsfield.ai");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleNavigate = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1200);
  };

  const activeUrl = liveUrl ?? "";

  return (
    <div
      className={`flex h-full flex-col overflow-hidden ${isFullscreen ? "fixed inset-0 z-50" : ""}`}
      style={{ background: "var(--background)" }}
    >
      {/* Browser chrome */}
      <div className="flex h-12 shrink-0 items-center gap-2 border-b px-3" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
        {/* Traffic lights */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="size-3 rounded-full bg-[#FF5F57]" />
          <div className="size-3 rounded-full bg-[#FEBC2E]" />
          <div className="size-3 rounded-full bg-[#28C840]" />
        </div>

        {/* Nav buttons */}
        <div className="flex items-center gap-1">
          <button className="p-1.5 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
            <ArrowLeftIcon className="size-3.5" />
          </button>
          <button className="p-1.5 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
            <ArrowRightIcon className="size-3.5" />
          </button>
          <button onClick={() => { setLoading(true); setTimeout(() => setLoading(false), 1200); }} className="p-1.5 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
            {loading ? <RefreshCwIcon className="size-3.5 animate-spin" /> : <RefreshCwIcon className="size-3.5" />}
          </button>
        </div>

        {/* URL bar */}
        <div className="flex-1 flex items-center gap-2 rounded-md px-3 py-1 border" style={{ borderColor: "var(--border)", background: "var(--secondary)" }}>
          {liveUrl ? (
            <div className="flex items-center gap-1.5 flex-1">
              <span className="size-1.5 rounded-full bg-[color:var(--success)] shrink-0" />
              <span className="text-xs truncate" style={{ color: "var(--muted-foreground)" }}>
                {liveUrl}
              </span>
            </div>
          ) : (
            <input
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.nativeEvent.isComposing) handleNavigate(); }}
              className="flex-1 bg-transparent text-xs focus:outline-none"
              style={{ color: "var(--foreground)" }}
              placeholder="Enter URL..."
            />
          )}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsFullscreen((v) => !v)}
            className="p-1.5 rounded hover:bg-white/10 transition-colors"
            style={{ color: "var(--muted-foreground)" }}
          >
            {isFullscreen ? <Minimize2Icon className="size-3.5" /> : <Maximize2Icon className="size-3.5" />}
          </button>
        </div>
      </div>

      {/* Browser content */}
      <div className="flex-1 relative overflow-hidden">
        {liveUrl ? (
          <iframe
            allow="clipboard-read; clipboard-write"
            className="absolute inset-0 w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin"
            src={liveUrl}
            title="Cloud browser"
          />
        ) : (
          <div className="h-full flex flex-col items-center justify-center gap-5">
            <div className="size-20 rounded-2xl bg-white/5 flex items-center justify-center">
              <MonitorIcon className="size-10" style={{ color: "var(--muted-foreground)" }} />
            </div>
            <div className="text-center">
              <h3 className="text-base font-medium mb-1">Cloud Browser</h3>
              <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                Start a browsing session from the Claude Brain tab,<br />and the live view will appear here.
              </p>
            </div>

            {/* Quick links */}
            <div className="grid grid-cols-3 gap-2 mt-2">
              {[
                { label: "Higgsfield AI", url: "https://higgsfield.ai", color: "#8b5cf6" },
                { label: "Arcads", url: "https://arcads.ai", color: "#6366f1" },
                { label: "Google Drive", url: "https://drive.google.com", color: "#4285F4" },
                { label: "Composio", url: "https://composio.dev", color: "#f59e0b" },
                { label: "Instagram", url: "https://instagram.com", color: "#E1306C" },
                { label: "TikTok", url: "https://tiktok.com", color: "#69C9D0" },
              ].map((link) => (
                <button
                  key={link.label}
                  onClick={() => setUrlInput(link.url)}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-lg border hover:bg-white/5 transition-colors"
                  style={{ borderColor: "var(--border)" }}
                >
                  <span className="size-7 rounded-lg flex items-center justify-center text-white font-bold text-xs" style={{ background: link.color }}>
                    {link.label[0]}
                  </span>
                  <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{link.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
