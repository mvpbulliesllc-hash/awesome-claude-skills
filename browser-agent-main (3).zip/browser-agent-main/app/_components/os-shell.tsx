"use client";

import {
  type EveMessage,
  type EveMessageData,
  type UseEveAgentHelpers,
  useEveAgent,
} from "eve/react";
import { AlertCircleIcon } from "lucide-react";
import { useState } from "react";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  PromptInput,
  type PromptInputMessage,
  PromptInputSubmit,
  PromptInputTextarea,
} from "@/components/ai-elements/prompt-input";
import { cn } from "@/lib/utils";
import { AgentMessage } from "./agent-message";
import { AgentsDashboard } from "./agents-dashboard";
import { AutomationPanel } from "./automation-panel";
import { CloudBrowserView } from "./cloud-browser-view";
import { ContentStudio } from "./content-studio";
import { DrivePanel } from "./drive-panel";
import { KnowledgeBase } from "./knowledge-base";
import { Sidebar, type Section } from "./sidebar";
import { SocialHub } from "./social-hub";

const BETA_TERMS_HREF = "https://vercel.com/docs/release-phases/public-beta-agreement";

function isLiveUrl(url: unknown): url is string {
  if (typeof url !== "string") return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && parsed.hostname === "live.browser-use.com";
  } catch {
    return false;
  }
}

function extractLiveUrl(messages: readonly EveMessage[]): string | null {
  let found: string | null = null;
  for (const message of messages) {
    for (const part of message.parts) {
      if (part.type !== "dynamic-tool" || part.toolName !== "open_cloud_browser") continue;
      const out = part.output;
      let url: unknown;
      if (out && typeof out === "object" && "liveUrl" in out) {
        url = (out as { liveUrl?: unknown }).liveUrl;
      } else if (typeof out === "string") {
        url = out.match(/https:\/\/live\.browser-use\.com[^\s"'\\]*/)?.[0];
      }
      if (isLiveUrl(url)) found = url;
    }
  }
  return found;
}

export function OSShell() {
  const [activeSection, setActiveSection] = useState<Section>("agents");
  const agent = useEveAgent();
  const isBusy = agent.status === "submitted" || agent.status === "streaming";
  const isEmpty = agent.data.messages.length === 0;
  const liveUrl = extractLiveUrl(agent.data.messages);

  const handleSubmit = async (message: PromptInputMessage) => {
    const text = message.text.trim();
    if (!text || isBusy) return;
    await agent.send({ message: text });
  };

  // Hand a prompt to Claude Brain from any panel (e.g. "Generate with AI"),
  // switching to the chat view so the user sees the run.
  const sendToBrain = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setActiveSection("chat");
    if (!isBusy) await agent.send({ message: trimmed });
  };

  const renderSection = () => {
    switch (activeSection) {
      case "agents":
        return <AgentsDashboard />;
      case "automation":
        return <AutomationPanel />;
      case "knowledge":
        return <KnowledgeBase />;
      case "content-studio":
        return <ContentStudio onSendToBrain={sendToBrain} />;
      case "social-hub":
        return <SocialHub onSendToBrain={sendToBrain} />;
      case "drive":
        return <DrivePanel />;
      case "cloud-browser":
        return <CloudBrowserView liveUrl={liveUrl} />;
      case "chat":
        return <ClaudeBrainChat agent={agent} isBusy={isBusy} isEmpty={isEmpty} onSubmit={handleSubmit} />;
      default:
        return <AgentsDashboard />;
    }
  };

  return (
    <div className="flex h-dvh overflow-hidden" style={{ background: "var(--background)" }}>
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />

      {/* Main content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <header
          className="flex h-14 shrink-0 items-center justify-between px-5 border-b"
          style={{ borderColor: "var(--border)", background: "var(--card)" }}
        >
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium capitalize">
              {activeSection === "chat" ? "Claude Brain" : activeSection.replace("-", " ")}
            </span>
            {liveUrl && (
              <div className="flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] border border-[color:var(--success)]/30 text-[color:var(--success)]">
                <span className="relative flex size-1.5">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-[color:var(--success)] opacity-60" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-[color:var(--success)]" />
                </span>
                Browser active
              </div>
            )}
          </div>
          <div className="flex items-center gap-3">
            {(agent.status === "submitted" || agent.status === "streaming") && (
              <div className="flex items-center gap-1.5 text-xs" style={{ color: "var(--muted-foreground)" }}>
                <span className="relative flex size-1.5">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-violet-400 opacity-75" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-violet-400" />
                </span>
                Claude is thinking...
              </div>
            )}
            <a
              className="rounded-full border border-amber-500/30 px-2 py-0.5 font-medium text-amber-400 text-xs transition-colors hover:bg-amber-500/10"
              href={BETA_TERMS_HREF}
              rel="noreferrer"
              target="_blank"
            >
              Public preview
            </a>
          </div>
        </header>

        {/* Section content */}
        <div className="flex-1 overflow-hidden">
          {renderSection()}
        </div>
      </div>
    </div>
  );
}

// Claude Brain tab — the original agent chat
function ClaudeBrainChat({
  agent,
  isBusy,
  isEmpty,
  onSubmit,
}: {
  agent: UseEveAgentHelpers<EveMessageData>;
  isBusy: boolean;
  isEmpty: boolean;
  onSubmit: (msg: PromptInputMessage) => Promise<void>;
}) {
  const composer = (
    <PromptInput onSubmit={onSubmit}>
      <PromptInputTextarea placeholder="Ask Claude to browse, create content, sync Drive, or publish to social..." />
      <PromptInputSubmit onStop={agent.stop} status={agent.status} />
    </PromptInput>
  );

  return (
    <div className="flex h-full flex-col overflow-hidden">
      {agent.error ? (
        <div className="mx-auto w-full max-w-3xl shrink-0 px-4 pt-4">
          <div className="flex items-start gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2.5 text-sm">
            <AlertCircleIcon className="mt-0.5 size-4 shrink-0 text-destructive" />
            <div>
              <p className="font-medium">Request failed</p>
              <p className="mt-0.5" style={{ color: "var(--muted-foreground)" }}>{agent.error.message}</p>
            </div>
          </div>
        </div>
      ) : null}

      {isEmpty ? null : (
        <Conversation className="min-h-0 flex-1">
          <ConversationContent className="mx-auto w-full max-w-3xl gap-6 px-4 py-6 sm:px-6">
            {agent.data.messages.map((message, index) => (
              <AgentMessage
                canRespond={!isBusy}
                isStreaming={
                  agent.status === "streaming" && index === agent.data.messages.length - 1
                }
                key={message.id}
                message={message}
                onInputResponses={(inputResponses) => agent.send({ inputResponses })}
              />
            ))}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>
      )}

      <div
        className={cn(
          "mx-auto w-full px-4 sm:px-6",
          isEmpty
            ? "flex max-w-xl flex-1 flex-col items-center justify-center gap-8 pb-[8vh]"
            : "max-w-3xl shrink-0 pb-6",
        )}
      >
        {isEmpty ? (
          <div className="flex flex-col items-center gap-4 text-center">
            <div className="size-16 rounded-2xl bg-white/5 flex items-center justify-center">
              <span className="text-3xl">✦</span>
            </div>
            <div>
              <h1 className="font-semibold text-3xl tracking-tight mb-2">Claude Brain</h1>
              <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
                Powered by Claude MCP — browse the web, create content, sync Drive, and publish to all socials.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 w-full max-w-md">
              {[
                "Generate a TikTok video brief for product launch",
                "Upload latest renders to Google Drive",
                "Post to Instagram, TikTok and X simultaneously",
                "Research trending hooks for my niche",
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  className="rounded-lg border p-3 text-left text-xs hover:bg-white/5 transition-colors"
                  style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : null}
        <div className="w-full">{composer}</div>
      </div>
    </div>
  );
}
