"use client";

import {
  BotIcon,
  CheckCircleIcon,
  ChevronRightIcon,
  ClockIcon,
  DollarSignIcon,
  FilterIcon,
  PlusIcon,
  SearchIcon,
  TrendingUpIcon,
} from "lucide-react";

const AGENTS = [
  {
    id: "content-creator",
    name: "Content Creator",
    description: "Generates video scripts, captions, and hooks from briefs. Uploads to Google Drive automatically.",
    tags: ["Higgsfield", "Google Drive", "Scripts"],
    status: "Active",
    tasks: 132,
    success: 98,
    color: "bg-violet-500",
    primary: true,
  },
  {
    id: "social-distributor",
    name: "Social Distributor",
    description: "Publishes finished content across all connected social platforms via Composio.",
    tags: ["Composio", "Social", "Publishing"],
    status: "Active",
    tasks: 86,
    success: 95,
    color: "bg-blue-500",
  },
  {
    id: "research-agent",
    name: "Research Agent",
    description: "Researches topics, summarizes insights, and delivers actionable briefs for content creation.",
    tags: ["Research", "Analysis", "Summarization"],
    status: "Active",
    tasks: 54,
    success: 97,
    color: "bg-emerald-500",
  },
  {
    id: "drive-sync",
    name: "Drive Sync Agent",
    description: "Monitors Google Drive for new content, syncs assets, and triggers distribution workflows.",
    tags: ["Google Drive", "Sync", "Automation"],
    status: "Active",
    tasks: 128,
    success: 94,
    color: "bg-amber-500",
  },
];

const RECENT_ACTIVITY = [
  { agent: "Content Creator", action: "Generated TikTok script", time: "2 min ago", status: "Success" },
  { agent: "Social Distributor", action: "Posted to Instagram + X", time: "5 min ago", status: "Success" },
  { agent: "Research Agent", action: "Generated market report", time: "15 min ago", status: "Success" },
  { agent: "Drive Sync Agent", action: "Synced 12 assets from Drive", time: "23 min ago", status: "Success" },
];

const PERF_BARS = [
  { day: "Mon", values: [60, 45, 70, 40] },
  { day: "Tue", values: [70, 55, 80, 50] },
  { day: "Wed", values: [65, 60, 75, 45] },
  { day: "Thu", values: [80, 70, 85, 55] },
  { day: "Fri", values: [75, 65, 90, 60] },
  { day: "Sat", values: [50, 40, 60, 35] },
  { day: "Sun", values: [55, 45, 65, 40] },
];

export function AgentsDashboard() {
  return (
    <div className="flex h-full overflow-hidden">
      {/* Main */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
                <BotIcon className="size-3" />
                Agents
              </div>
            </div>
            <h1 className="text-2xl font-semibold tracking-tight">AI agents that work like your best team</h1>
            <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
              Deploy intelligent agents that understand goals, make decisions, perform tasks, and continuously improve.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm border hover:bg-white/5 transition-colors" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              Browse templates
            </button>
            <button className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium bg-white text-black hover:bg-white/90 transition-colors">
              <PlusIcon className="size-3.5" />
              New agent
            </button>
          </div>
        </div>

        {/* Search + Filter */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-xs">
            <SearchIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5" style={{ color: "var(--muted-foreground)" }} />
            <input
              placeholder="Search agents..."
              className="w-full rounded-md pl-8 pr-3 py-1.5 text-sm border focus:outline-none focus:ring-1 focus:ring-white/20 bg-transparent"
              style={{ borderColor: "var(--border)" }}
            />
          </div>
          <button className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm border hover:bg-white/5 transition-colors" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
            <FilterIcon className="size-3.5" />
            Filter
          </button>
        </div>

        {/* Agents list */}
        <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
          <div className="grid grid-cols-[2fr_1fr_1fr_1fr_auto] px-4 py-2.5 text-xs border-b" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
            <span>Agent</span>
            <span>Trigger</span>
            <span>Last run</span>
            <span>Status</span>
            <span />
          </div>
          {AGENTS.map((agent, i) => (
            <div key={agent.id} className={`grid grid-cols-[2fr_1fr_1fr_1fr_auto] items-center px-4 py-3 hover:bg-white/3 transition-colors ${i < AGENTS.length - 1 ? "border-b" : ""}`} style={{ borderColor: "var(--border)" }}>
              <div className="flex items-start gap-3">
                <div className={`size-8 rounded-md ${agent.color} flex items-center justify-center shrink-0 mt-0.5`}>
                  <BotIcon className="size-4 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{agent.name}</span>
                    {agent.primary && (
                      <span className="rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-violet-500/20 text-violet-300">Primary</span>
                    )}
                  </div>
                  <p className="text-xs mt-0.5 leading-relaxed max-w-xs" style={{ color: "var(--muted-foreground)" }}>{agent.description}</p>
                  <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                    {agent.tags.map((tag) => (
                      <span key={tag} className="rounded px-1.5 py-0.5 text-[10px] border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
              <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>New content added</span>
              <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>2 min ago</span>
              <div className="flex items-center gap-1.5">
                <span className="size-1.5 rounded-full bg-[color:var(--success)]" />
                <span className="text-xs text-[color:var(--success)]">{agent.status}</span>
              </div>
              <button className="p-1 rounded hover:bg-white/10 transition-colors" style={{ color: "var(--muted-foreground)" }}>
                <ChevronRightIcon className="size-4" />
              </button>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-center py-2">
          <button className="flex items-center gap-1 text-sm hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
            View all agents <ChevronRightIcon className="size-3.5" />
          </button>
        </div>
      </div>

      {/* Right panel */}
      <aside className="w-64 shrink-0 border-l overflow-y-auto p-4 space-y-5" style={{ borderColor: "var(--border)", background: "var(--panel)" }}>
        {/* Stats */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold">Agent activity</span>
            <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>Today</span>
          </div>
          <div className="space-y-3">
            {[
              { label: "Tasks completed", value: "402", delta: "+18%", icon: <CheckCircleIcon className="size-3.5" /> },
              { label: "Success rate", value: "96.4%", delta: "+3%", icon: <TrendingUpIcon className="size-3.5" /> },
              { label: "Time saved", value: "128h", delta: "+22%", icon: <ClockIcon className="size-3.5" /> },
              { label: "Cost saved", value: "$12,540", delta: "+16%", icon: <DollarSignIcon className="size-3.5" /> },
            ].map((stat) => (
              <div key={stat.label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span style={{ color: "var(--muted-foreground)" }}>{stat.icon}</span>
                  <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{stat.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{stat.value}</span>
                  <span className="text-[10px] text-[color:var(--success)]">{stat.delta}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        {/* Recent activity */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold">Recent agent activity</span>
            <button className="text-[10px] hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>View all</button>
          </div>
          <div className="space-y-2.5">
            {RECENT_ACTIVITY.map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <div className="size-6 rounded-md bg-white/10 flex items-center justify-center shrink-0 mt-0.5">
                  <BotIcon className="size-3" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">{item.agent}</div>
                  <div className="text-[10px] truncate" style={{ color: "var(--muted-foreground)" }}>{item.action}</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{item.time}</span>
                    <span className="text-[10px] text-[color:var(--success)]">{item.status}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        {/* Performance chart */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold">Agent performance</span>
            <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>This week</span>
          </div>
          <div className="flex items-end gap-1 h-16">
            {PERF_BARS.map((bar) => (
              <div key={bar.day} className="flex-1 flex flex-col items-center gap-0.5">
                <div className="w-full flex flex-col-reverse gap-px" style={{ height: 52 }}>
                  {bar.values.map((v, i) => (
                    <div
                      key={i}
                      className="w-full rounded-sm opacity-80"
                      style={{
                        height: `${v * 0.52}%`,
                        background: ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b"][i],
                        minHeight: 2,
                      }}
                    />
                  ))}
                </div>
                <span className="text-[9px]" style={{ color: "var(--muted-foreground)" }}>{bar.day}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-3 mt-2 flex-wrap">
            {["Content", "Social", "Research", "Drive"].map((label, i) => (
              <div key={label} className="flex items-center gap-1">
                <span className="size-1.5 rounded-full" style={{ background: ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b"][i] }} />
                <span className="text-[9px]" style={{ color: "var(--muted-foreground)" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
