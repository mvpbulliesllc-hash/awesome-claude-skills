"use client";

import {
  BotIcon,
  DatabaseIcon,
  GlobeIcon,
  HardDriveIcon,
  InboxIcon,
  LayersIcon,
  LayoutDashboardIcon,
  MonitorIcon,
  PaletteIcon,
  Share2Icon,
  SlidersIcon,
  SparklesIcon,
  VideoIcon,
  ZapIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

export type Section =
  | "agents"
  | "automation"
  | "knowledge"
  | "content-studio"
  | "social-hub"
  | "cloud-browser"
  | "drive"
  | "chat";

interface SidebarProps {
  activeSection: Section;
  onSectionChange: (section: Section) => void;
}

const NAV_ITEMS: {
  id: Section;
  label: string;
  icon: React.ReactNode;
  group: string;
}[] = [
  { id: "agents", label: "Agents", icon: <BotIcon className="size-4" />, group: "workspace" },
  { id: "automation", label: "Automation", icon: <ZapIcon className="size-4" />, group: "workspace" },
  { id: "knowledge", label: "Knowledge Base", icon: <DatabaseIcon className="size-4" />, group: "workspace" },
  { id: "content-studio", label: "Content Studio", icon: <VideoIcon className="size-4" />, group: "create" },
  { id: "social-hub", label: "Social Hub", icon: <Share2Icon className="size-4" />, group: "create" },
  { id: "drive", label: "Google Drive", icon: <HardDriveIcon className="size-4" />, group: "create" },
  { id: "cloud-browser", label: "Cloud Browser", icon: <MonitorIcon className="size-4" />, group: "tools" },
  { id: "chat", label: "Claude Brain", icon: <SparklesIcon className="size-4" />, group: "tools" },
];

const GROUP_LABELS: Record<string, string> = {
  workspace: "Workspace",
  create: "Create",
  tools: "Tools",
};

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const groups = Array.from(new Set(NAV_ITEMS.map((i) => i.group)));

  return (
    <aside
      className="flex h-full w-56 shrink-0 flex-col border-r"
      style={{ background: "var(--sidebar)", borderColor: "var(--sidebar-border)" }}
    >
      {/* Logo */}
      <div className="flex h-14 shrink-0 items-center gap-2.5 px-4 border-b" style={{ borderColor: "var(--sidebar-border)" }}>
        <div className="flex size-7 items-center justify-center rounded-md bg-white/10">
          <LayersIcon className="size-4 text-white" />
        </div>
        <div>
          <div className="font-semibold text-sm leading-tight text-white">EcoAI Studio</div>
          <div className="text-[10px] leading-tight" style={{ color: "var(--muted-foreground)" }}>
            Content OS
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {groups.map((group) => (
          <div key={group}>
            <div
              className="px-2 pb-1 text-[10px] font-semibold uppercase tracking-widest"
              style={{ color: "var(--muted-foreground)" }}
            >
              {GROUP_LABELS[group]}
            </div>
            <div className="space-y-0.5">
              {NAV_ITEMS.filter((i) => i.group === group).map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-sm transition-colors text-left",
                    activeSection === item.id
                      ? "bg-white/10 text-white"
                      : "text-[color:var(--muted-foreground)] hover:bg-white/5 hover:text-white"
                  )}
                >
                  <span
                    className={cn(
                      "shrink-0 transition-colors",
                      activeSection === item.id ? "text-white" : "text-[color:var(--muted-foreground)]"
                    )}
                  >
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                  {activeSection === item.id && (
                    <span className="ml-auto size-1.5 rounded-full bg-[color:var(--success)]" />
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Bottom status */}
      <div className="shrink-0 px-3 py-3 border-t space-y-2" style={{ borderColor: "var(--sidebar-border)" }}>
        <div className="flex items-center gap-2 px-1">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-[color:var(--success)] opacity-60" />
            <span className="relative inline-flex size-2 rounded-full bg-[color:var(--success)]" />
          </span>
          <span className="text-xs text-[color:var(--muted-foreground)]">Claude MCP Active</span>
        </div>
        <div className="flex items-center gap-2 px-1">
          <span className="size-2 rounded-full bg-blue-400" />
          <span className="text-xs text-[color:var(--muted-foreground)]">Composio Connected</span>
        </div>
      </div>
    </aside>
  );
}
