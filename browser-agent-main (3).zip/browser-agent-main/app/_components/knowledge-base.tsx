"use client";

import {
  DatabaseIcon,
  FileTextIcon,
  FolderIcon,
  GlobeIcon,
  PlusIcon,
  RefreshCwIcon,
  UsersIcon,
} from "lucide-react";

const CONNECTED_SOURCES = [
  { name: "Google Drive", count: "342 docs", dot: "#4285F4" },
  { name: "Google Workspace", count: "180 files", dot: "#34A853" },
  { name: "Composio MCP", count: "12 connectors", dot: "#6366f1" },
  { name: "Web Crawler", count: "8 databases", dot: "#f59e0b" },
  { name: "Higgsfield Assets", count: "24 videos", dot: "#8b5cf6" },
];

const COLLECTIONS = [
  { name: "Content Briefs", count: 129, updated: "2h ago", icon: <FileTextIcon className="size-4" />, color: "text-blue-400" },
  { name: "Campaign Scripts", count: 88, updated: "5h ago", icon: <FolderIcon className="size-4" />, color: "text-violet-400" },
  { name: "Brand Guidelines", count: 212, updated: "1h ago", icon: <UsersIcon className="size-4" />, color: "text-emerald-400" },
  { name: "Analytics Docs", count: 64, updated: "3h ago", icon: <DatabaseIcon className="size-4" />, color: "text-amber-400" },
];

const RECENT_ACTIVITY = [
  { file: "Q3 content roadmap.pdf", action: "added to Content Briefs", by: "Agent AI Sync", time: "1h ago" },
  { file: "TikTok hooks v3.docx", action: "was synced from Drive", time: "2h ago" },
  { file: "Brand voice v2.pdf", action: "was updated", by: "Drive Sync Agent", time: "3h ago" },
  { file: "Campaign brief July.pdf", action: "was added", by: "by Jorl", time: "4h ago" },
];

const AGENT_ACCESS = [
  { name: "Content Creator", status: "Up to date" },
  { name: "Social Distributor", status: "Up to date" },
  { name: "Research Agent", status: "Syncing" },
  { name: "Drive Sync Agent", status: "Up to date" },
];

export function KnowledgeBase() {
  return (
    <div className="flex h-full overflow-hidden">
      {/* Main */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <DatabaseIcon className="size-3" />
              Knowledge Base
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">A shared knowledge base for every AI agent</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
            Centralize company knowledge from documents, Google Drive, and internal tools so every agent operates with accurate, real-time context.
          </p>
          <button className="mt-4 flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium bg-white text-black hover:bg-white/90 transition-colors">
            <PlusIcon className="size-3.5" />
            Add source
          </button>
        </div>

        {/* Collections */}
        <div>
          <h3 className="text-sm font-medium mb-3">Collections</h3>
          <div className="grid grid-cols-4 gap-3">
            {COLLECTIONS.map((col) => (
              <button
                key={col.name}
                className="rounded-lg border p-4 text-left hover:bg-white/3 transition-colors"
                style={{ borderColor: "var(--border)", background: "var(--card)" }}
              >
                <div className={`mb-2 ${col.color}`}>{col.icon}</div>
                <div className="text-sm font-medium">{col.name}</div>
                <div className="text-xs mt-1" style={{ color: "var(--muted-foreground)" }}>{col.count} items</div>
                <div className="text-[10px] mt-0.5" style={{ color: "var(--muted-foreground)" }}>Updated {col.updated}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Recent activity */}
        <div>
          <h3 className="text-sm font-medium mb-3">Recent activity</h3>
          <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
            {RECENT_ACTIVITY.map((item, i) => (
              <div
                key={i}
                className={`flex items-center gap-3 px-4 py-3 hover:bg-white/3 transition-colors ${i < RECENT_ACTIVITY.length - 1 ? "border-b" : ""}`}
                style={{ borderColor: "var(--border)" }}
              >
                <div className="size-7 rounded-md bg-white/10 flex items-center justify-center shrink-0">
                  <FileTextIcon className="size-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-sm font-medium">{item.file}</span>
                  <span className="text-sm" style={{ color: "var(--muted-foreground)" }}> {item.action}</span>
                  {item.by && <span className="text-sm" style={{ color: "var(--muted-foreground)" }}> {item.by}</span>}
                </div>
                <span className="text-xs shrink-0" style={{ color: "var(--muted-foreground)" }}>{item.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <aside className="w-64 shrink-0 border-l overflow-y-auto p-4 space-y-5" style={{ borderColor: "var(--border)", background: "var(--panel)" }}>
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold">Connected sources</span>
          </div>
          <div className="space-y-2.5">
            {CONNECTED_SOURCES.map((src) => (
              <div key={src.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="size-4 rounded" style={{ background: src.dot }} />
                  <span className="text-xs">{src.name}</span>
                </div>
                <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{src.count}</span>
              </div>
            ))}
            <button className="flex items-center gap-1.5 mt-1 text-xs hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
              <PlusIcon className="size-3" />
              Connect a source
            </button>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-3">Agent access</div>
          <div className="space-y-2">
            {AGENT_ACCESS.map((agent) => (
              <div key={agent.name} className="flex items-center justify-between">
                <span className="text-xs">{agent.name}</span>
                <div className="flex items-center gap-1">
                  {agent.status === "Syncing" ? (
                    <RefreshCwIcon className="size-3 text-blue-400 animate-spin" />
                  ) : (
                    <span className="size-1.5 rounded-full bg-[color:var(--success)]" />
                  )}
                  <span className={`text-[10px] ${agent.status === "Syncing" ? "text-blue-400" : "text-[color:var(--success)]"}`}>
                    {agent.status}
                  </span>
                </div>
              </div>
            ))}
            <button className="flex items-center gap-1.5 mt-1 text-xs hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
              Manage agents &amp; permissions
            </button>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-2">Sync status</div>
          <div className="flex items-center gap-2">
            <span className="size-2 rounded-full bg-[color:var(--success)]" />
            <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>All sources are up to date</span>
          </div>
        </div>
      </aside>
    </div>
  );
}
