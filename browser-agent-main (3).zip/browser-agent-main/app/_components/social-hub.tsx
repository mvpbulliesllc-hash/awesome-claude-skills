"use client";

import {
  CheckCircleIcon,
  ExternalLinkIcon,
  GlobeIcon,
  HeartIcon,
  PlusIcon,
  SendIcon,
  Share2Icon,
  SparklesIcon,
  TriangleAlertIcon,
  UsersIcon,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";

const SOCIAL_PLATFORMS = [
  { name: "Instagram", handle: "@ecoaisolutions", followers: "24.5K", status: "Connected", color: "#E1306C", posts: 3 },
  { name: "TikTok", handle: "@ecoaisolutions", followers: "68.2K", status: "Connected", color: "#010101", borderColor: "#69C9D0", posts: 7 },
  { name: "X / Twitter", handle: "@EcoAISolutions", followers: "12.1K", status: "Connected", color: "#1DA1F2", posts: 12 },
  { name: "YouTube", handle: "EcoAI Solutions", followers: "8.4K", status: "Connected", color: "#FF0000", posts: 2 },
  { name: "LinkedIn", handle: "EcoAI Solutions", followers: "5.2K", status: "Connected", color: "#0077B5", posts: 4 },
  { name: "Facebook", handle: "EcoAI Solutions", followers: "3.1K", status: "Connected", color: "#1877F2", posts: 2 },
  { name: "Pinterest", handle: "@ecoaisolutions", followers: "1.8K", status: "Connected", color: "#E60023", posts: 1 },
  { name: "Threads", handle: "@ecoaisolutions", followers: "2.3K", status: "Connected", color: "#101010", posts: 5 },
];

const SCHEDULED_POSTS = [
  { platform: "Instagram", content: "Launching our new AI content pipeline — create, render, distribute 10x faster.", time: "Today 2:00 PM", status: "Scheduled" },
  { platform: "TikTok", content: "POV: Your content agent handles everything while you sleep", time: "Today 4:30 PM", status: "Scheduled" },
  { platform: "X / Twitter", content: "Thread: How we automated our entire content workflow with Claude MCP + Composio", time: "Tomorrow 9:00 AM", status: "Draft" },
];

const ANALYTICS = [
  { label: "Total followers", value: "125.6K", delta: "+3.2K", icon: <UsersIcon className="size-4" /> },
  { label: "Engagements", value: "48.2K", delta: "+12%", icon: <HeartIcon className="size-4" /> },
  { label: "Reach", value: "892K", delta: "+24%", icon: <GlobeIcon className="size-4" /> },
  { label: "Post published", value: "36", delta: "+8", icon: <Share2Icon className="size-4" /> },
];

const platformSlug = (name: string): string =>
  name.toLowerCase().replace("x / twitter", "twitter");

export function SocialHub({ onSendToBrain }: { onSendToBrain?: (text: string) => void }) {
  const [composerText, setComposerText] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["Instagram", "TikTok"]);
  const [publishing, setPublishing] = useState(false);
  const [publishResult, setPublishResult] = useState<string | null>(null);
  const [publishOk, setPublishOk] = useState(false);
  const [connectedSlugs, setConnectedSlugs] = useState<Set<string> | null>(null);
  const [composioError, setComposioError] = useState<string | null>(null);

  const loadConnections = useCallback(async () => {
    try {
      const res = await fetch("/api/composio");
      const data = await res.json();
      if (!res.ok) {
        setComposioError(data.error ?? "Composio not configured");
        setConnectedSlugs(new Set());
        return;
      }
      // Heuristic: scan the connected-accounts payload for each platform's
      // app name so the UI reflects what's actually linked in Composio.
      const blob = JSON.stringify(data.connections ?? data).toLowerCase();
      const found = new Set<string>();
      for (const p of SOCIAL_PLATFORMS) {
        const slug = platformSlug(p.name);
        if (blob.includes(slug) || (slug === "twitter" && blob.includes("twitter"))) {
          found.add(slug);
        }
      }
      setConnectedSlugs(found);
      setComposioError(null);
    } catch {
      setComposioError("Network error reaching Composio");
      setConnectedSlugs(new Set());
    }
  }, []);

  useEffect(() => {
    loadConnections();
  }, [loadConnections]);

  const isConnected = (name: string) =>
    connectedSlugs === null ? true : connectedSlugs.has(platformSlug(name));

  const togglePlatform = (name: string) => {
    setSelectedPlatforms((prev) =>
      prev.includes(name) ? prev.filter((p) => p !== name) : [...prev, name]
    );
  };

  const handlePublish = async () => {
    if (!composerText.trim() || selectedPlatforms.length === 0 || publishing) return;
    setPublishing(true);
    setPublishResult(null);
    try {
      const res = await fetch("/api/composio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "publish",
          platforms: selectedPlatforms.map(platformSlug),
          caption: composerText,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        const entries = Object.entries(
          data.results as Record<string, { success?: boolean; error?: string }>,
        );
        const ok = entries.filter(([, v]) => v.success).map(([k]) => k);
        const failed = entries.filter(([, v]) => v.error).map(([k]) => k);
        setPublishOk(ok.length > 0 && failed.length === 0);
        setPublishResult(
          [
            ok.length ? `Published to ${ok.join(", ")}` : "",
            failed.length ? `Failed: ${failed.join(", ")}` : "",
          ]
            .filter(Boolean)
            .join(" · ") || "No platforms targeted",
        );
        if (ok.length) setComposerText("");
      } else {
        setPublishOk(false);
        setPublishResult(`Error: ${data.error ?? "publish failed"}`);
      }
    } catch {
      setPublishOk(false);
      setPublishResult("Network error — check console");
    } finally {
      setPublishing(false);
    }
  };

  const handleAIGenerate = () => {
    const platforms = selectedPlatforms.join(", ") || "all connected platforms";
    const seed = composerText.trim();
    onSendToBrain?.(
      `Write a high-performing social post for ${platforms}.${seed ? ` Topic/notes: ${seed}` : ""} Then, if it looks good, publish it via Composio.`,
    );
  };

  const connectedCount = connectedSlugs?.size ?? SOCIAL_PLATFORMS.length;

  return (
    <div className="flex h-full overflow-hidden">
      {/* Main */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border" style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}>
              <Share2Icon className="size-3" />
              Social Hub
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">All social connectors, one place</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted-foreground)" }}>
            Powered by Composio — publish, schedule, and monitor content across every platform simultaneously.
          </p>
        </div>

        {/* Analytics row */}
        <div className="grid grid-cols-4 gap-3">
          {ANALYTICS.map((stat) => (
            <div key={stat.label} className="rounded-lg border p-4" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
              <div className="flex items-center justify-between mb-2">
                <span style={{ color: "var(--muted-foreground)" }}>{stat.icon}</span>
                <span className="text-[10px] text-[color:var(--success)]">{stat.delta}</span>
              </div>
              <div className="text-xl font-semibold">{stat.value}</div>
              <div className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)" }}>{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Composer */}
        <div className="rounded-xl border p-5" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
          <h3 className="text-sm font-medium mb-3">Compose &amp; distribute</h3>
          <textarea
            placeholder="Write your post... or let Claude Brain generate it for you."
            value={composerText}
            onChange={(e) => setComposerText(e.target.value)}
            className="w-full rounded-lg border px-3 py-2.5 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-white/20 bg-transparent leading-relaxed"
            style={{ borderColor: "var(--border)", minHeight: 80 }}
          />
          <div className="mt-3">
            <div className="text-xs mb-2" style={{ color: "var(--muted-foreground)" }}>Publish to:</div>
            <div className="flex flex-wrap gap-2 mb-3">
              {SOCIAL_PLATFORMS.map((p) => (
                <button
                  key={p.name}
                  onClick={() => togglePlatform(p.name)}
                  className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors border ${selectedPlatforms.includes(p.name) ? "text-white" : "text-[color:var(--muted-foreground)] hover:text-white"}`}
                  style={{
                    borderColor: selectedPlatforms.includes(p.name) ? p.color : "var(--border)",
                    background: selectedPlatforms.includes(p.name) ? p.color + "30" : "transparent",
                  }}
                >
                  {p.name}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePublish}
                disabled={publishing || !composerText.trim() || selectedPlatforms.length === 0}
                className="flex items-center gap-1.5 rounded-md px-4 py-2 text-sm font-medium bg-white text-black hover:bg-white/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <SendIcon className="size-3.5" />
                {publishing ? "Publishing..." : "Publish now"}
              </button>
              <button
                onClick={handleAIGenerate}
                className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm border hover:bg-white/5 transition-colors"
                style={{ borderColor: "var(--border)", color: "var(--muted-foreground)" }}
              >
                <SparklesIcon className="size-3.5" />
                AI Generate
              </button>
            </div>
            {publishResult && (
              <div
                className="mt-3 flex items-start gap-2 rounded-md border px-3 py-2 text-xs"
                style={{
                  borderColor: publishOk ? "var(--success)" : "var(--destructive)",
                  background: `color-mix(in srgb, var(--${publishOk ? "success" : "destructive"}) 8%, transparent)`,
                }}
              >
                {publishOk ? (
                  <CheckCircleIcon className="size-3.5 shrink-0 mt-0.5 text-[color:var(--success)]" />
                ) : (
                  <TriangleAlertIcon className="size-3.5 shrink-0 mt-0.5 text-[color:var(--destructive)]" />
                )}
                <span style={{ color: "var(--muted-foreground)" }}>{publishResult}</span>
              </div>
            )}
          </div>
        </div>

        {/* Scheduled */}
        <div>
          <h3 className="text-sm font-medium mb-3">Scheduled posts</h3>
          <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
            {SCHEDULED_POSTS.map((post, i) => (
              <div
                key={i}
                className={`flex items-start gap-3 px-4 py-3 hover:bg-white/3 transition-colors ${i < SCHEDULED_POSTS.length - 1 ? "border-b" : ""}`}
                style={{ borderColor: "var(--border)" }}
              >
                <div className="size-8 rounded-md flex items-center justify-center shrink-0 mt-0.5 text-white text-[10px] font-bold" style={{ background: SOCIAL_PLATFORMS.find((p) => p.name === post.platform)?.color ?? "#666" }}>
                  {post.platform[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm" style={{ color: "var(--muted-foreground)" }}>{post.content}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{post.time}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${post.status === "Scheduled" ? "text-[color:var(--success)] bg-[color:var(--success)]/10" : "text-[color:var(--warning)] bg-[color:var(--warning)]/10"}`}>
                      {post.status}
                    </span>
                  </div>
                </div>
                <button className="p-1 rounded hover:bg-white/10 transition-colors shrink-0" style={{ color: "var(--muted-foreground)" }}>
                  <ExternalLinkIcon className="size-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <aside className="w-64 shrink-0 border-l overflow-y-auto p-4 space-y-5" style={{ borderColor: "var(--border)", background: "var(--panel)" }}>
        <div>
          <div className="text-xs font-semibold mb-3">Connected platforms</div>
          <div className="space-y-2">
            {SOCIAL_PLATFORMS.map((platform) => (
              <div key={platform.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="size-5 rounded flex items-center justify-center text-white text-[9px] font-bold shrink-0" style={{ background: platform.color }}>
                    {platform.name[0]}
                  </span>
                  <div>
                    <div className="text-xs font-medium">{platform.name}</div>
                    <div className="text-[10px]" style={{ color: "var(--muted-foreground)" }}>{platform.followers}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <span
                    className={`size-1.5 rounded-full ${isConnected(platform.name) ? "bg-[color:var(--success)]" : "bg-white/20"}`}
                    title={isConnected(platform.name) ? "Connected" : "Not connected"}
                  />
                </div>
              </div>
            ))}
            <button className="flex items-center gap-1.5 mt-1 text-xs hover:text-white transition-colors" style={{ color: "var(--muted-foreground)" }}>
              <PlusIcon className="size-3" />
              Add platform
            </button>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-2">Composio status</div>
          <div className="rounded-md p-3 border" style={{ borderColor: "var(--border)", background: "var(--secondary)" }}>
            <div className="flex items-center gap-2 mb-2">
              <span className={`size-2 rounded-full ${composioError ? "bg-[color:var(--warning)]" : "bg-[color:var(--success)]"}`} />
              <span className="text-xs font-medium">
                {composioError ? "Composio not configured" : `${connectedCount} connector${connectedCount === 1 ? "" : "s"} active`}
              </span>
            </div>
            <div className="text-[10px] leading-relaxed" style={{ color: "var(--muted-foreground)" }}>
              {composioError
                ? composioError
                : `Social platforms linked via Composio. Claude Brain can publish to any of them.`}
            </div>
          </div>
        </div>

        <div className="border-t" style={{ borderColor: "var(--border)" }} />

        <div>
          <div className="text-xs font-semibold mb-2">This month</div>
          <div className="space-y-2">
            {[
              { label: "Posts published", value: "36" },
              { label: "Total reach", value: "892K" },
              { label: "Avg. engagement", value: "5.4%" },
            ].map((stat) => (
              <div key={stat.label} className="flex items-center justify-between">
                <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>{stat.label}</span>
                <span className="text-sm font-semibold">{stat.value}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
