/**
 * Composio API proxy — social publishing + connector status.
 * Logic lives in lib/composio.ts (shared with the agent's tools).
 *
 * GET  /api/composio                                     — list connected apps
 * POST /api/composio { action: "status" }                — list connected apps
 * POST /api/composio { action: "publish", platforms, caption, mediaUrl? }
 * POST /api/composio { action: "execute", appName?, actionName, params? }
 */

import { type NextRequest, NextResponse } from "next/server";
import {
  executeAction,
  listConnections,
  publishToSocial,
} from "@/lib/composio";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === "status") {
      return NextResponse.json({
        success: true,
        connections: await listConnections(),
      });
    }

    if (action === "publish") {
      const { platforms, caption, mediaUrl } = body as {
        platforms: string[];
        caption: string;
        mediaUrl?: string;
      };
      const results = await publishToSocial(platforms, caption, mediaUrl);
      return NextResponse.json({ success: true, results });
    }

    if (action === "execute") {
      const { appName, actionName, params } = body;
      const data = await executeAction(appName, actionName, params ?? {});
      return NextResponse.json({ success: true, data });
    }

    return NextResponse.json(
      { error: `Unknown action: ${action}` },
      { status: 400 },
    );
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function GET() {
  try {
    return NextResponse.json({
      success: true,
      connections: await listConnections(),
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
