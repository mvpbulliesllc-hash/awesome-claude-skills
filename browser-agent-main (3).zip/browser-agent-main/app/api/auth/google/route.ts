/**
 * Google OAuth 2.0 — Drive + Workspace scopes
 * GET  /api/auth/google          — redirect to Google consent screen
 * GET  /api/auth/google/callback — exchange code for tokens, store refresh token
 *
 * After successful auth, GOOGLE_REFRESH_TOKEN is stored in process memory
 * for the session. For production: persist it in your database or env.
 */

import { type NextRequest, NextResponse } from "next/server";

const SCOPES = [
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/drive.readonly",
  "https://www.googleapis.com/auth/gmail.readonly",
  "openid",
  "email",
  "profile",
].join(" ");

export async function GET(req: NextRequest) {
  const { searchParams, origin } = new URL(req.url);
  const code = searchParams.get("code");

  // Callback — exchange code for tokens
  if (code) {
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: `${origin}/api/auth/google`,
        grant_type: "authorization_code",
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      return NextResponse.json({ error: `Token exchange failed: ${err}` }, { status: 400 });
    }

    const tokens = await res.json();
    // In a real app persist refresh_token in DB or env
    // For now return it so the user can add it as GOOGLE_REFRESH_TOKEN
    return NextResponse.json({
      success: true,
      message: "Connected! Add the refresh_token below as GOOGLE_REFRESH_TOKEN in your project settings.",
      refresh_token: tokens.refresh_token,
      access_token: tokens.access_token,
      expires_in: tokens.expires_in,
    });
  }

  // Initial redirect to Google
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: `${origin}/api/auth/google`,
    response_type: "code",
    scope: SCOPES,
    access_type: "offline",
    prompt: "consent",
  });

  return NextResponse.redirect(
    `https://accounts.google.com/o/oauth2/v2/auth?${params}`,
  );
}
