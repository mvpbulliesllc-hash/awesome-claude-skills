/**
 * Google Drive API proxy.
 * Logic lives in lib/drive.ts (shared with the agent's Drive tools).
 *
 * GET    /api/drive?folder=<id>          — list files in a folder (root default)
 * GET    /api/drive?download=<fileId>    — stream a file's bytes
 * POST   /api/drive                      — upload (multipart/form-data: file + folder)
 * POST   /api/drive { url, name, folder } — upload from a remote URL (JSON)
 * DELETE /api/drive?id=<fileId>          — trash a file
 */

import { type NextRequest, NextResponse } from "next/server";
import {
  downloadFile,
  getStorage,
  isDriveConfigured,
  listFiles,
  trashFile,
  uploadFile,
  uploadFromUrl,
} from "@/lib/drive";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);

    // Download a file's bytes
    const downloadId = searchParams.get("download");
    if (downloadId) {
      const res = await downloadFile(downloadId);
      if (!res.ok) {
        return NextResponse.json(
          { error: await res.text() },
          { status: res.status },
        );
      }
      return new NextResponse(res.body, {
        headers: {
          "Content-Type":
            res.headers.get("content-type") ?? "application/octet-stream",
          "Content-Disposition": `attachment; filename="${searchParams.get("name") ?? downloadId}"`,
        },
      });
    }

    // Storage quota
    if (searchParams.get("about") === "1") {
      return NextResponse.json({ success: true, storage: await getStorage() });
    }

    // List files
    const folder = searchParams.get("folder") ?? "root";
    const pageToken = searchParams.get("pageToken") ?? undefined;
    const listing = await listFiles(folder, pageToken);
    return NextResponse.json({ success: true, ...listing });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    const status = isDriveConfigured() ? 500 : 400;
    return NextResponse.json({ error: message }, { status });
  }
}

export async function POST(req: NextRequest) {
  try {
    const contentType = req.headers.get("content-type") ?? "";

    // JSON form: upload from a remote URL
    if (contentType.includes("application/json")) {
      const { url, name, folder } = (await req.json()) as {
        url: string;
        name: string;
        folder?: string;
      };
      if (!url || !name) {
        return NextResponse.json(
          { error: "`url` and `name` are required" },
          { status: 400 },
        );
      }
      const file = await uploadFromUrl(url, name, folder ?? "root");
      return NextResponse.json({ success: true, file });
    }

    // Multipart form: direct file upload
    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const folder = (formData.get("folder") as string) || "root";
    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const uploaded = await uploadFile(
      file.name,
      await file.arrayBuffer(),
      file.type || "application/octet-stream",
      folder,
    );
    return NextResponse.json({ success: true, file: uploaded });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const fileId = searchParams.get("id");
    if (!fileId) {
      return NextResponse.json({ error: "Missing file id" }, { status: 400 });
    }
    await trashFile(fileId);
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
