/**
 * Arcads MCP + n8n workflow proxy.
 * Logic lives in lib/mcp.ts (shared with the agent's automation tools).
 *
 * GET  /api/arcads                                  — list tools from both servers
 * POST /api/arcads { service, method, params? }     — raw JSON-RPC call
 * POST /api/arcads { service, tool, arguments? }     — invoke a named MCP tool
 */

import { type NextRequest, NextResponse } from "next/server";
import { isConfigured, listTools, mcpCall, type McpService } from "@/lib/mcp";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { service, method, params, tool, arguments: args } = body as {
      service: McpService;
      method?: string;
      params?: Record<string, unknown>;
      tool?: string;
      arguments?: Record<string, unknown>;
    };

    if (service !== "arcads" && service !== "n8n") {
      return NextResponse.json(
        { error: `Unknown service: ${service}` },
        { status: 400 },
      );
    }

    // Convenience form: { service, tool, arguments } → tools/call
    if (tool) {
      const data = await mcpCall(service, "tools/call", {
        name: tool,
        arguments: args ?? {},
      });
      return NextResponse.json({ success: true, data });
    }

    if (!method) {
      return NextResponse.json(
        { error: "Provide either `method` or `tool`" },
        { status: 400 },
      );
    }

    const data = await mcpCall(service, method, params ?? {});
    return NextResponse.json({ success: true, data });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// GET — list available tools from both MCP servers
export async function GET() {
  const services: Record<string, unknown> = {};

  for (const service of ["arcads", "n8n"] as const) {
    if (!isConfigured(service)) {
      services[service] = { configured: false };
      continue;
    }
    try {
      services[service] = { configured: true, tools: await listTools(service) };
    } catch (err: unknown) {
      services[service] = {
        configured: true,
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  return NextResponse.json({ success: true, services });
}
