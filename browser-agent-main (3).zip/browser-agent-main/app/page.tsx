import { OSShell } from "@/app/_components/os-shell";

export default function Page() {
  return <OSShell />;
}
